#!/usr/bin/env python
#coding:utf-8
"""
  Author:  zhangShengXin --<>
  Purpose: 从腾讯网站股票最新交易数据，如：http://qt.gtimg.cn/q=sz000858;
    获取实时资金流向，如：http://qt.gtimg.cn/q=ff_sz000858；
    获取实时盘口，如：http://qt.gtimg.cn/q=s_pksz000858；
    获取简要信息，如：http://qt.gtimg.cn/q=s_sz000858；
  
  Created: 2016/12/24
  name: getStockData.py
"""
import shanghaiAgu,zhongXiaoban,chuangyeban
import unittest
import urllib, urllib2, urlparse
import sys, os,re
import threading
import sqlite3
CreateTabelString =  '''create table if not exists {0}(code,名字,代码,当前价格,昨收,今开,成交量手,外盘,内盘,买一,买一量手,买二,买二量手,买三,买三量手,买四,买四量手,买五,买五量手,卖一,卖一量手,卖二,卖二量手,卖三,卖三量手,卖四,卖四量手,卖五,卖五量手,最近逐笔成交,时间,涨跌,涨幅,最高,最低,价格成交量手成交额,成交量手A,成交额万,换手率,市盈率,nu,最高价,最低价,振幅,流通市值,总市值,市净率,涨停价,跌停价,主力流入,主力流出,主力净流入,主力净流入资金流入流出总和,散户流入,散户流出,散户净流入,散户净流入资金流入流出总和,资金流入流出总和,未知,未知1,日期)'''

InsertString =  '''insert into {0} values (code,名字,代码,当前价格,昨收,今开,成交量手,外盘,内盘,买一,买一量手,买二,买二量手,买三,买三量手,买四,买四量手,买五,买五量手,卖一,卖一量手,卖二,卖二量手,卖三,卖三量手,卖四,卖四量手,卖五,卖五量手,最近逐笔成交,时间,涨跌,涨幅,最高,最低,价格成交量手成交额,成交量手A,成交额万,换手率,市盈率,nu,最高价,最低价,振幅,流通市值,总市值,市净率,涨停价,跌停价,主力流入,主力流出,主力净流入,主力净流入资金流入流出总和,散户流入,散户流出,散户净流入,散户净流入资金流入流出总和,资金流入流出总和,未知,未知1,日期)'''


path = os.path.dirname(__file__).replace('\\', '/')
sqlPath_NewData = '{0}/data/newData.db'.format(path)
sqlPath_MoneyData = '{0}/data/MoneyData.db'.format(path)

#print sqlPath_NewData
if not os.path.exists(os.path.dirname(sqlPath_NewData)):
    os.mkdir(os.path.dirname(sqlPath_NewData))
if not os.path.exists(os.path.dirname(sqlPath_MoneyData)):
    os.mkdir(os.path.dirname(sqlPath_MoneyData))
history_DataPath = '{0}/history/'.format(path)
#print history_DataPath
if not os.path.exists(history_DataPath):
    os.mkdir(history_DataPath)
stokeList = []
for x in xrange(600000, 603999):
    stokeList.append('sh{0}'.format(x))
for x in xrange(1, 1999):
    stokeList.append('sz%06d' % x)
for x in xrange(2001, 2999):
    stokeList.append('sz%06d' % x)
#for x in xrange(300001, 300400):
    #stokeList.append('sz%06d' % x)
#print stokeList[:5]
#----------------------------------------------------------------------
class getStockNewData():
    """"""
    #----------------------------------------------------------------------
    def __init__(self):
        """"""
        self.missage = {0: 'code', 1: u'名字', 2: u'代码', 3: u'当前价格', 4: u'昨收', 5: u'今开',
                        6: u'成交量手', 7: u'外盘', 8: u'内盘',9: u'买一',10: u'买一量手',
                        11: u'买二', 12: u'买二量手', 13: u'买三', 14: u'买三量手', 15: u'买四',
                        16: u'买四量手', 17: u'买五', 18: u'买五量手',19: u'卖一',
                        20: u'卖一量手', 21: u'卖二', 22: u'卖二量手',23: u'卖三',
                        24: u'卖三量手', 25: u'卖四', 26: u'卖四量手',27: u'卖五',
                        28: u'卖五量手',29: u'最近逐笔成交' , 30: u'时间', 31: u'涨跌',
                        32: u'涨幅', 33: u'最高', 34:u'最低',35: u'价格成交量手成交额',
                        36: u'成交量手A', 37: u'成交额万', 38: u'换手率', 39: u'市盈率',
                        40: u'nu',41: u'最高价', 42: u'最低价', 43: u'振幅', 44: u'流通市值',
                        45: u'总市值',46: u'市净率', 47: u'涨停价', 48: u'跌停价'}
        self.url = 'http://qt.gtimg.cn/q='
        #最近逐笔成交
        self.DealsWill= {0: u'时间', 1: u'成交价（元）', 2: u'成交量', 3: u'性质'}
    #----------------------------------------------------------------------
    def connectSql(self,dataBasePath):
        """"""
        conn = sqlite3.connect(dataBasePath)
        return conn    
    #----------------------------------------------------------------------
    def connetToWeb(self, stockCode):
        """"""
        data = urllib2.urlopen(self.url + stockCode, data=None, timeout=3)
        datainfo= data.read().decode('gb2312')
        dataOut = datainfo.split('~')
        if len(dataOut) > 1:
            return dataOut
        else:
            return None
    #----------------------------------------------------------------------
    def getData(self, stockCode):
        """
        {0: ('', u'v_sz000858="51'), 1: (u'名字', u'五 粮 液'), 2: (u'代码', u'000858'), 3: ...., 48: (u'跌停价', u'31.87')}

        """
        dataInfo = self.connetToWeb(stockCode)
        if dataInfo != None:
            outdata = {}
            for n in xrange(len(self.missage)):
                if dataInfo[n] == '':
                    outdata[n] = (self.missage[n], 'nu')
                else:outdata[n] = (self.missage[n], dataInfo[n])
            return outdata
        else:return None
    def getDataMore(self, stockCodeList=[]):
        url =  self.url

        for i in stockCodeList:
            url += i + ','
        try:
            data = urllib.urlopen(url)
            #print url
            datainfo= data.read().decode('gbk')
            data.close()
            dataout =  datainfo.split(';')
            outData = {}
            num = 0
            NoneCode =  stockCodeList[::]
            if len(dataout) > 1:
                for x in xrange(len(dataout)):
                    oneData = {}
                    sp =  dataout[x].split('~')
     
                    if sp !=  None and len(sp) > 1:
                        code =  sp[0].split('=')[0].split('_')[1]
                        NoneCode.remove(u'%s' % code)
                        for n in xrange(len(self.missage)):
                            #print sp[n]
                            if sp[n] == '':
                                oneData[n] = (self.missage[n], 'nu')
                            else:oneData[n] =  (self.missage[n], sp[n])
                    num += 1
                    outData[x] =  oneData
                 
            else:
                outData = {}
            #print NoneCode
            if len(NoneCode) > 0:
                for i in  NoneCode:
                    oneData = {}
                    for n in xrange(len(self.missage)):
                        if  n ==len(self.missage) -1:
                            oneData[n] =  (self.missage[n], i[2:])
                        else:
                            oneData[n] =  (self.missage[n], 0)
                    num += 1
                    outData[num] =  oneData
            #print datainfo
            return outData
        except EOFError ,e:
            print e 
            outData={}
            return   outData     
    def getDataMorePandas(self, stockCodeList=[], toSql = False):
        url =  self.url

        for i in stockCodeList:
            url += i + ','
        #print url
        data = urllib.urlopen(url)
        
        datainfo= data.read().decode('gbk')
        data.close()
        dataout =  datainfo.split(';')
        outData = {}
        num = 0
        NoneCode =  stockCodeList[::]
        if len(dataout) > 1:
            for x in xrange(len(dataout)):
                oneData = {}
                sp =  dataout[x].split('~')
 
                if sp !=  None and len(sp) > 1:
                    code =  sp[0].split('=')[0].split('_')[1]
                    NoneCode.remove(u'%s' % code)
                    for n in xrange(len(self.missage)):
                        #print sp[n]
                        if sp[n] == '':
                            oneData[n] = 'nu'
                        else:
                            if n not in [0, 1, 2, 29,30, 35, 40]:
                                oneData[n] =  float(sp[n])
                            else:
                                oneData[n] = sp[n]

                    if toSql:
                        
                        stock = re.findall('.*_(.*)=', oneData[0])  #匹配 '_'和'='之间的文章
                        print u'写入 {0} 交易数据到SQL'.format(stock[0])
                        conn = self.connectSql(sqlPath_NewData)
                        cu = conn.cursor()
                        sqlCreate= 'create table if not exists {0}(code,名字,代码,当前价格,昨收,今开,成交量手,外盘,内盘,买一,买一量手,买二,买二量手,买三,买三量手,买四,买四量手,买五,买五量手,卖一,卖一量手,卖二,卖二量手,卖三,卖三量手,卖四,卖四量手,卖五,卖五量手,最近逐笔成交,时间,涨跌,涨幅,最高,最低,价格成交量手成交额,成交量手A,成交额万,换手率,市盈率,nu,最高价,最低价,振幅,流通市值,总市值,市净率,涨停价,跌停价)'
                        
                        cu.execute(sqlCreate.format(stock[0]))
                        
                        sqlInsert= 'insert into {0} values({1}?)'.format(stock[0],'?,'*(len(self.missage.keys())-1))
                        #print sqlInsert
                        cu.execute(sqlInsert, oneData.values())
                        conn.commit()
                        cu.close()
                        conn.close() 
                        #print num,oneData
                    num += 1
                    outData[x] = oneData                        
        else:
            outData = {}
        #print NoneCode
        if len(NoneCode) > 0:
            for i in  NoneCode:
                oneData = {}
                for n in xrange(len(self.missage)):
                    if  n ==len(self.missage) -1:
                        oneData[n] =  i[2:]
                    else:
                        oneData[n] =   0
                num += 1
                outData[num] =  oneData
        #print datainfo
        return outData
########################################################################
class getStockMoney():
    """"""

    #----------------------------------------------------------------------
    def __init__(self):
        """Constructor"""
        self.url = 'http://qt.gtimg.cn/q=ff_'
        self.missage = { 0: u'code', 1: u'主力流入', 2: u'主力流出', 3: u'主力净流入',
                         4: u'主力净流入资金流入流出总和', 
                         5: u'散户流入',6 : u'散户流出',7: u'散户净流入', 8:u'散户净流入资金流入流出总和',
                         9: u'资金流入流出总和', 10: u'未知',11: u'未知1', 12: u'名字',13: u'日期',
                         14: u'代码',
                         }
    #----------------------------------------------------------------------
    def connectSql(self,dataBasePath):
        """"""
        conn = sqlite3.connect(dataBasePath)
        return conn  
    #----------------------------------------------------------------------
    def connetToWeb(self, stockCode):
        """"""
        data = urllib2.urlopen(self.url + stockCode, data=None, timeout=3)
        datainfo= data.read().decode('gb2312')
        dataOut = datainfo.split('~')
        if len(dataOut) > 1:
            return dataOut
        else:
            return None
    #----------------------------------------------------------------------
    def getData(self, stockCode):
        """
        {0: ('', u'v_sz000858="51'), 1: (u'名字', u'五粮液'), 2: (u'代码', u'000858'), 3: ...., 48: (u'跌停价', u'31.87')}

        """
        dataInfo = self.connetToWeb(stockCode)
        if dataInfo != None:
            #print len(dataInfo), dataInfo
            outdata = {}
            for n in xrange(len(self.missage)):
                outdata[n] = (self.missage[n], dataInfo[n])
            return outdata
        else:return None
    def getDataMore(self, stockCodeList=[]):
        url =  self.url[:-3]
    
        for i in stockCodeList:
            url += 'ff_%s' % i + ','
        try:
            data = urllib.urlopen(url)
            #print url
            datainfo= data.read().decode('gbk')
            data.close()
            dataout =  datainfo.split(';')
            outData = {}
            num = 0
            NoneMoneyCode =  stockCodeList[::]
            if len(dataout) > 1:
                for x in xrange(len(dataout)):
                    oneData = {}
                    sp =  dataout[x].split('~')
        
                    if sp !=  None and len(sp) > 1:
                        if sp[0].split('"')[1] in stockCodeList:
                            NoneMoneyCode.remove(sp[0].split('"')[1])
                        for n in xrange(len(self.missage)):
                            #print sp[n]
                            if sp[n] == '':
                                oneData[n] = (self.missage[n], 'nu')
                            else:
                                if  n ==len(self.missage) -1:
                                    oneData[n] =  (self.missage[n], sp[0].split('"')[1][2:])
                                else:
                                    oneData[n] =  (self.missage[n], sp[n])
                    num += 1
        
                    outData[x] =  oneData
            else:
                outData = {}
            if len(NoneMoneyCode) > 0:
                for i in  NoneMoneyCode:
                    oneData = {}
                    for n in xrange(len(self.missage)):
                        if  n ==len(self.missage) -1:
                            oneData[n] =  (self.missage[n], i[2:])
                        else:
                            oneData[n] =  (self.missage[n], 0)
                    num += 1
                    outData[num] =  oneData
            #print num
            return outData
        except EOFError, e:
            print e 
            outData = {} 
            return  outData
        
    def getDataMorePandas(self, stockCodeList=[],toSql=False):
        url =  self.url[:-3]
    
        for i in stockCodeList:
            url += 'ff_%s' % i + ','
        data = urllib2.urlopen(url)
        #print url
        datainfo= data.read().decode('gbk')
        data.close()
        dataout =  datainfo.split(';')
        outData = {}
        num = 0
        NoneMoneyCode =  stockCodeList[::]
        if len(dataout) > 1:
            for x in xrange(len(dataout)):
                oneData = {}
                sp =  dataout[x].split('~')
    
                if sp !=  None and len(sp) > 1 :
                    if sp[0].split('"')[1] in stockCodeList:
                        NoneMoneyCode.remove(sp[0].split('"')[1])
                    for n in xrange(len(self.missage)):
                        #print sp[n]
                        if sp[n] == '':
                            oneData[n] = 'nu'
                        else:
                            if  n ==len(self.missage) -1:
                                oneData[n] =  sp[0].split('"')[1][2:]
                            else:
                                if n not in [0, 12, 13]:
                                    oneData[n] =   float(sp[n])
                                else:
                                    oneData[n] =   sp[n]
                                    
                    if toSql:
                        code = re.findall('.*_(.*)=', oneData[0])  #匹配 '_'和'='之间的文字
                        print u'写入 {0} 资金数据到SQL'.format(code[0])
                        conn = self.connectSql(sqlPath_MoneyData)
                        cu = conn.cursor()
                        
                        sqlCreate= 'create table if not exists {0} (code,主力流入,主力流出,主力净流入,主力净流入资金流入流出总和,散户流入,散户流出,散户净流入,散户净流入资金流入流出总和,资金流入流出总和,未知,未知1,名字,日期,代码)'
                        cu.execute(sqlCreate.format(code[0]))
                        sqlInsert = 'insert into {0} values({1}?)'.format(code[0],'?,'*(len(self.missage.keys())-1))
                        #print sqlInsert, oneData.values()
                        cu.execute(sqlInsert, tuple(oneData.values()))
                        conn.commit()
                        conn.close()  
                num += 1
                outData[x] =  oneData                
        else:
            outData = {}
        if len(NoneMoneyCode) > 0:
            for i in  NoneMoneyCode:
                oneData = {}
                for n in xrange(len(self.missage)):
                    if  n ==len(self.missage) -1:
                        oneData[n] =  i[2:]
                    else:
                        oneData[n] =  0
                num += 1
                outData[num] =  oneData
        #print num
        return outData
listStock=[]
class getHistory():
    """
    获取历史数据
    周k 线数据    如: http://data.gtimg.cn/flashdata/hushen/weekly/sz000868.js
    日k线数据     如: http://data.gtimg.cn/flashdata/hushen/daily/13/sz000750.js
    月k线数据     如: http://data.gtimg.cn/flashdata/hushen/monthly/sz000868.js
    """
    global listStock
    #----------------------------------------------------------------------
    def __init__(self):
        """"""
        pass
    #----------------------------------------------------------------------
    def getDatas(self, stock='', dataType='daily', year=[2010, 2012, 2013, 2014, 2015, 2016, 2017], *args):
        """
        stock:     是股票代码
        dataType:  是daily,weely,monthly 三个中的一个，否则报错
        year:      是两个类，（all ，两位数的数字），只用于日线数据
        """
        if dataType in ['daily', 'weekly', 'monthly']:
            if dataType == "daily":
                if stock != None and stock != '':
                    if year == 'all':
                        url =  'http://data.gtimg.cn/flashdata/hushen/{daily}/{year}/{stock}.js'.format(
                                                    daily=dataType, year=year, stock=stock)
                    elif isinstance(year, list):   #判读年份是否问整数，是否2位数
                        data = ''
                        for i in year:
                            if len('%d'%i) == 4:
                                #print u'下载 {0} {1} 年日交易数据'.format(stock, i)
                                url =  'http://data.gtimg.cn/flashdata/hushen/{daily}/{year}/{stock}.js'.format(
                                                        daily=dataType, year=str(i)[2:], stock=stock)
                                try:
                                    conn = urllib2.urlopen(url, data=None, timeout=3)
                                    datas = conn.read().decode('gb2312').encode('utf-8')
                                    data1 = self.data_processing(datas)                                    
                                except Exception,e:
                                    print e
                                    data = None
                                    return data

                                if data1 != None:
                                    try:
                                        data += data1
                                        data += '\n'                                        
                                    except:
                                        pass
                                else:
                                    data = None
                                #print url
                            elif len('%d'%i) == 2:
                                #print u'下载 {0} {1} 年日交易数据'.format(stock, i)
                                url =  'http://data.gtimg.cn/flashdata/hushen/{daily}/{year}/{stock}.js'.format(
                                                                                        daily=dataType, year=i, stock=stock)
                                
                                conn = urllib.urlopen(url, data=None, timeout=3)
                                datas = conn.read().decode('gb2312').encode('utf-8')
                                
                            else:
                                raise EOFError('typeEorr')
                        return data
                    else:
                        print  EOFError('typeEorr')
                        
                        #csv = urllib.urlretrieve(url, '{0}.csv'.format(stock))
                        #print csv
                        
                else:
                    print "No stock"
            elif dataType == "weekly":
                if stock != None and stock != '':
                    #print u'下载 {0} 周交易数据'.format(stock)
                    url =  'http://data.gtimg.cn/flashdata/hushen/{daily}/{stock}.js'.format(daily=dataType, stock=stock)
                    try:
                        conn = urllib2.urlopen(url, data=None, timeout=3)
                        datas = conn.read().decode('gb2312').encode('utf-8')
                        data = self.data_processing(datas)                        
                    except Exception , e:
                        print 'Exception>>', e
                        data = None
                        return data

                    if data != None:
                        return data
                    else:
                        return None                    
                else:
                    print "No stock"
            elif dataType == 'monthly':
                if stock != None and stock != '':
                    #print u'下载｛0｝月交易数据'.format(stock)
                    url =  'http://data.gtimg.cn/flashdata/hushen/{daily}/{stock}.js'.format(daily=dataType, stock=stock)
                    try:
                        conn = urllib2.urlopen(url, data=None, timeout=3)
                        datas = conn.read().decode('gb2312').encode('utf-8')
                        data = self.data_processing(datas)                        
                    except Exception , e:
                        print 'Exception>>', e
                        data = None
                        return data
                    
                    if data != None:
                        return data
                    else:
                        return None                    
                else:print "No stock"
            else:
                print "dataType Eorro"
    #----------------------------------------------------------------------
    def data_processing(self, datas):
        """"""
        #splitLines = [x.replace('\\n\\', '') for x in datas.splitlines()]
        if datas.find('404 Not Found') != -1:
            return None
        else:
            splitLines = datas.split('\\n\\\n')
            dataJ = '\n'.join(['20%s'%x for x in splitLines[1:-1]])
            return dataJ
#----------------------------------------------------------------------
def getNewData(stockCode = 'sh601668'):
    """"""
    data = getStockNewData()
    dataOut = data.getData(stockCode)
    return dataOut
#----------------------------------------------------------------------
def getMoney(stockCode = 'sh601668'):
    """"""
    money =getStockMoney()
    moneyData = money.getData(stockCode)
    return moneyData
#----------------------------------------------------------------------
def writeDataToExce():
    """"""

    reload(zhongXiaoban)
    reload(shanghaiAgu)
    import xlrd, xlwt
    import time
    data = getStockNewData()
    dataMoney = getStockMoney()
    outData = [] #[{0:{0:('df','dd'),1:('fe','tt')}},{1:{0:(0,'d'),1:(1,'f')}},......]
    for x in range(0, len(shanghaiAgu.stockCode1), 40):
        o =  data.getDataMore(shanghaiAgu.stockCode1[x:x+40])
        outData.append(o)
    MoneyOutData = []
    for x in range(0, len(shanghaiAgu.stockCode1), 20):
        m = dataMoney.getDataMore(shanghaiAgu.stockCode1[x:x+20])
        MoneyOutData.append(m)
        #time.sleep(2)
    #zhongxiaoban
    outDataZ = []
    for x in range(0, len(zhongXiaoban.stockCode1), 40):
        z =  data.getDataMore(zhongXiaoban.stockCode1[x:x+40])
        outDataZ.append(z)
        
    MoneyOutDataZ = []
    for x in range(0, len(zhongXiaoban.stockCode1), 20):
        m = dataMoney.getDataMore(zhongXiaoban.stockCode1[x:x+20])
        MoneyOutDataZ.append(m)
        #time.sleep(2)
    print len(outData), len(shanghaiAgu.stockCode1)
    print len(outDataZ), len(zhongXiaoban.stockCode1)
    #写入exec文件
    #----------------------------------------------------------------------
    fl =  xlwt.Workbook()
    table =  fl.add_sheet('shanghaiAgu', cell_overwrite_ok=True)
    table1 =  fl.add_sheet('zhongxiaoban', cell_overwrite_ok=True)
    tableMeneyS = fl.add_sheet('shanghaiAguMoney', cell_overwrite_ok=True)
    tableMeneyZ = fl.add_sheet('zhongxiaobanMoney', cell_overwrite_ok=True)
    for k, v in data.missage.items():
        table.write(0, k, v)
        table1.write(0, k, v)
        
    for k, v in  dataMoney.missage.items():
        tableMeneyS.write(0, k, v)
        tableMeneyZ.write(0, k, v)
    n = 0
    for out in outData:
        if out != {}:
            for k, v in out.items():
                if len(v.items()) != 0:
                    for k1, v1 in v.items():
                        #print n, k, k1, v1[0], v1[1]
                        try:
                            if v1[1].startwith('0') != True and '.' not in v1[1]:
                                if v1[0] == u'日期' or v1[0] == u'时间':
                                    value = datetime.datetime(v1[1])
                                else:
                                    value = int(v1[1])
                        except:
                            try:
                                value = float(v1[1])
                            except:
                                value = v1[1]
                        table.write(n+1, k1, value)
                    n += 1
    n = 0
    for out in outDataZ:
        if out != {}:
            for k, v in out.items():
                if len(v.items()) != 0:
                    for k1, v1 in v.items():
                        #print n, k, k1, v1[0], v1[1]
                        try:
                            if v1[1].startwith('0') != True and '.' not in v1[1]:
                                if v1[0] == u'日期' or v1[0] == u'时间':
                                    value = datetime.datetime.strftime(v1[1], "%Y%m%d%H%M%S")
                                else:
                                    value = int(v1[1])
                        except:
                            try:
                                value = float(v1[1])
                            except:
                                value = v1[1]
                        table1.write(n + 1, k1, value)
                    n += 1
    #write Money -------------------------------------------
    n = 0
    for out in MoneyOutData:
        if out != {}:
            for k, v in out.items():
                if len(v.items()) != 0:
                    for k1, v1 in v.items():
                        #print n, k, k1, v1[0], v1[1]
                        try:
                            if v1[1].startwith('0') != True and '.' not in v1[1]:
                                if v1[0] == u'时间':
                                    value =  v1[1]#datetime.datetime.strftime(v1[1], "%Y%m%d%H%M%S")
                                else:
                                    value = int(v1[1])
                        except:
                            try:
                                value = float(v1[1])
                            except:
                                value = v1[1]
                        tableMeneyS.write(n+1, k1, value)
                    n += 1    
    n = 0
    for out in MoneyOutDataZ:
        if out != {}:
            for k, v in out.items():
                if len(v.items()) != 0:
                    for k1, v1 in v.items():
                        #print n, k, k1, v1[0], v1[1]
                        try:
                            if v1[1].startwith('0') != True and '.' not in v1[1]:
                                if  v1[0] == u'时间':
                                    value =  v1[1]#datetime.datetime.strftime(v1[1], "%Y%m%d%H%M%S")
                                else:
                                    value = int(v1[1])
                        except:
                            try:
                                value = float(v1[1])
                            except:
                                value = v1[1]
                        tableMeneyZ.write(n+1, k1, value)
                    n += 1    
    fl.save(os.path.dirname(__file__).replace('\\', '/')+'/out.xls')
    #print MoneyOutData
    print ("Write Data to Exec seccese")
    return os.path.dirname(__file__).replace('\\', '/')+'/out.xls'
#----------------------------------------------------------------------
def writeToCsv(path, data):
    """"""
    #if os.path.exists(path):
    #    f = open(path, 'r')
    #    da = f.read()
    #    f.close()
    #    f = open(path, 'w')
    #    f.write(da)
    #    f.write('\n')
    #    f.write(data)
    #    f.close()
    #else:
    f = open(path, 'w')
    f.write(data)
    f.close()
        
#----------------------------------------------------------------------
def allHistory(stokeList):
    """"""
    import shanghaiAgu, zhongXiaoban
    result = {}
    for code in  stokeList:
    #for code in  shanghaiAgu.stockCode1 + zhongXiaoban.stockCode1:    
        print u'下载 {0} 交易数据'.format(code)
        his = getHistory()
        data = his.getDatas(code, dataType= 'daily',year=[ 2014, 2015, 2016, 2017])
        data1 = his.getDatas(code, dataType= 'weekly', year=[ 2014, 2015, 2016, 2017])
        data2 = his.getDatas(code, dataType=  'monthly', year=[ 2014, 2015, 2016, 2017])
        if data != None and data1 != None and data2 != None:
            writeToCsv('%s/%s_daily.csv' % (history_DataPath , code) , data)
            writeToCsv('%s/%s_weekly.csv' % (history_DataPath , code) , data1)        
            writeToCsv('%s/%s_monthly.csv' % (history_DataPath , code) , data2) 
            listStock.append(code)
            result[code] =True
        else:
            result[code] =False
    return result
#----------------------------------------------------------------------
def allHistory_daily(stokeList):
    """"""
    for code in  stokeList:
        print u'下载 {0} 日交易数据'.format(code)
        his = getHistory()
        data = his.getDatas(code, dataType= 'daily',year=[ 2014, 2015, 2016, 2017])
        if data != None:
            writeToCsv('%s/%s_daily.csv' % (history_DataPath , code) , data)
#----------------------------------------------------------------------
def allHistory_weekly(stokeList):
    """"""
    for code in  stokeList:
        print u'下载 {0} 周交易数据'.format(code)
        his = getHistory()
        data = his.getDatas(code, dataType= 'weekly', year=[ 2014, 2015, 2016, 2017])
        if data != None:
            writeToCsv('%s/%s_weekly.csv' % (history_DataPath , code) , data)
#----------------------------------------------------------------------
def allHistory_monthly(stokeList):
    """"""
    for code in  stokeList:
        print u'下载 {0} 月交易数据'.format(code)
        his = getHistory()
        data = his.getDatas(code, dataType=  'monthly', year=[ 2014, 2015, 2016, 2017])
        if data != None:
            writeToCsv('%s/%s_monthly.csv' % (history_DataPath , code) , data)
if __name__ == '__main__':
    
    #dataOut = data.getData('sh600268')
    
    '''f =  file(u'D:/pythonStudy/股票成交量化分析/scripts/out.txt', 'wb')
    f.write(unicode(out))
    f.write('\n')
    f.close()'''
    import datetime
    start = datetime.datetime.now()
    #d = getStockNewData()
    #m = getStockMoney()

    #for x in range(0, len(stokeList), 40):
        #o =  d.getDataMorePandas(stokeList[x:x+40],True)
        #l = m.getDataMorePandas(stokeList[x:x+40],True)
        #outData.append(o)
        #MoneyOutData.append(m)
    stokeList=shanghaiAgu.stockCode1+zhongXiaoban.stockCode1+chuangyeban.stockCode1
    allHistory(stokeList)
    #threads = []
    #t1 = threading.Thread(target = allHistory_daily())
    #threads.append(t1)
    #t2 = threading.Thread(target = allHistory_weekly())
    #threads.append(t2)
    #t3 = threading.Thread(target = allHistory_monthly())
    #threads.append(t3)
    #for t in threads:
    #    t.setDaemon(True)
    #    t.start()    
    #writeDataToExce()
    #print dataOut
    #for i in dataOut.items():
        #print i[1][0], i[1][1]
    #money =getStockMoney()
    #moneyData = money.getData('sh600268')
    ##print moneyData
    #for i in moneyData.items():
        #print i[1][0], i[1][1]
    #print listStock
    end = datetime.datetime.now()
    print start
    print end
    print u'耗时：{0}'.format( (end - start).seconds)
    unittest.main()
