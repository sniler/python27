# -*- coding: utf-8 -*-
import os, sys,time
filePath =  os.path.dirname(__file__).replace('\\', '/')
modPath =  '/'.join(filePath.split('/')[:-1])

rc =  'rc/'
if not os.path.exists(rc):
    os.mkdir(rc)

#from ui import  uiMainWindow
import shanghaiAgu,zhongXiaoban,chuangyeban
from  uiMainWindow import Ui_MainWindow
import  pandasStock
import urllib2, urllib
import requests
from StringIO import StringIO
from PIL import Image
from PIL import ImageFile
ImageFile.LOAD_TRUNCATED_IMAGES = True
import canShu
import getStockData
import threading
import utility
try:
    from  PyQt4 import QtCore, QtGui, uic
    import sip 
except:
    from PySide import QtCore, QtGui
    import pysideuic as uic
    import shiboken as sip
    
class GlobalOptions():
    '''
    全局变量设置
    '''
    # 如果用pyinstaller转换后，对应于exe文件的dist目录，下面的文件要要放在exe同目录下
    #stopwordsFile = r'data/English_stopwords.txt'
    stopwordsFile = 'icon1.png'
    
class ui( QtGui.QMainWindow, Ui_MainWindow):
    """"""
    windowTitleText = u'实时选股'
    #----------------------------------------------------------------------
    def __init__(self,  ):
        """Constructor"""
        super(ui, self).__init__()
        #self.event = QtCore.QEvent()
        self.isCheck='min'  #加载数据显示 实时(min) 日线(daily)  周线(weekly) 月线(monthly)
        if getattr(sys, 'frozen', False):
            self.pathname = r""
        else:
            self.pathname = os.path.split(os.path.realpath(__file__))[0]
        #print("pathname: " + pathname)
    
        stopwordsFile = GlobalOptions.stopwordsFile
        stopwordsFile = os.path.join(self.pathname, stopwordsFile)        
        
        self.setupUi(self)
        self.setWindowTitle(self.windowTitleText)
        self.setWindowIcon(QtGui.QIcon('icon.png'))   #stopwordsFile))
        #self.statusBar()
        self.statusBar().showMessage('Ready')
        
        self.canShu = canShu.Ui_Form() #uic.loadUi( '%s/canShu.ui' % filePath)
        self.widgetCanShu = QtGui.QWidget(self.splitter)
        self.canShu.setupUi(self.widgetCanShu)
        #self.canShu.Form.setParent(self.splitter)
        self.verticalLayout.insertWidget(3,self.widgetCanShu)
        self.splitter.setStretchFactor(1,1)
        #self.setFixedSize(self.width(), self.height());  
        #self.cView = uic.loadUi('%s/columnView.ui' % filePath )
        
        self.pandasData = None
        self.data =  QtCore.QStringList()
        #data.append('600027')
        dataL = [ '002608' , '600640', '600846' , '601666','601699','601231','601388']  #
        for i in  dataL:
            self.data.append(QtCore.QString(i))
        
        #print data.takeAt(0)
        self.model =  QtGui.QStringListModel(self.data)
        self.listWidget.setModel(self.model)
        #self.listWidget.addltems(data)
        
        self.button.clicked.connect(lambda *args:self.buttonCmd())
        self.listWidget.clicked.connect(lambda *args: self.ctiveCmd(self.isCheck))

        QtCore.QObject.connect(self.label_day, QtCore.SIGNAL("clicked()"), lambda *args: self.labelClink('daily'))
        QtCore.QObject.connect(self.label_time, QtCore.SIGNAL("clicked()"), lambda *args: self.labelClink('min'))
        QtCore.QObject.connect(self.zhou_time, QtCore.SIGNAL("clicked()"), lambda *args: self.labelClink('weekly'))
        QtCore.QObject.connect(self.monthly_time, QtCore.SIGNAL("clicked()"), lambda *args: self.labelClink('monthly'))
        
        self.count_lab =  QtGui.QLabel(self.layoutWidget)
        self.verticalLayout.addWidget(self.count_lab)
        self.count_lab.setText(u"选出的股票数量:%d"%len(self.data))
        self.count_lab.setAlignment(QtCore.Qt.AlignHCenter)   
    
        self.listWidget.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.setStatusTipText()
        self.createMenu()
        
        back = backendUpdataThreeding(self)
        back.update_date.connect(self.ctiveCmd)
        back.start()         
    #----------------------------------------------------------------------
    def createMenu(self):
        """"""

        self.exit = QtGui.QAction(u'退出',self,triggered=lambda *args : self.close())
        self.exit.setShortcut('Ctrl+Q')
        self.exit.setStatusTip(u'退出')
        self.connect(self.exit, QtCore.SIGNAL('triggered()'), QtCore.SLOT('close()'))
    
        self.fileMenu = self.menubar.addMenu(u'&文件')
        self.action = QtGui.QAction(u'导入自选股',self,triggered=lambda *args: self.importData())
        self.action.setShortcut('Ctrl+O')
        self.action.setObjectName("action")
        self.action.setStatusTip(u'导入自选股')
        self.action_2 = QtGui.QAction(u'导出数据',self,triggered=lambda *args: self.outPutData())
        self.action_2.setObjectName("action_2")
        self.action_2.setShortcut('Ctrl+S')
        self.action_2.setStatusTip(u'导出数据')
        self.fileMenu.addAction(self.action)
        self.fileMenu.addAction(self.action_2)
        self.fileMenu.addAction(self.exit)
        #创建选股菜单
        self.xuangu_menu = self.menubar.addMenu(u'&选股策略')
        self.day5_action = QtGui.QAction(u'股价大于5日均线的股票',self,triggered = lambda :self.xuanGuCmd(0))
        self.action.setObjectName("day5_action")
        self.action.setStatusTip(u'大于5日均线的股票')
        
        self.day5_mid_day10_da_day20_action = QtGui.QAction(u'股价在5,10日均线之间, 且大于20日均线',self,triggered = lambda :self.xuanGuCmd(1))
        self.day5_mid_day10_da_day20_action.setObjectName("day5_mid_day10_da_day20_action")
        self.day5_mid_day10_da_day20_action.setStatusTip(u'股价在5,10日均线之间, 且大于20日均线')  
        
        self.day10_mid_day20_action = QtGui.QAction(u'股价在10,20日均线之间',self,triggered = lambda :self.xuanGuCmd(2))
        self.day10_mid_day20_action.setObjectName("day10_mid_day20_action")
        self.day10_mid_day20_action.setStatusTip(u'股价在10,20日均线之间')   
        
        self.day20_mid_day30_action = QtGui.QAction(u'股价在20,30日均线之间',self,triggered = lambda :self.xuanGuCmd(3))
        self.day20_mid_day30_action.setObjectName("day20_mid_day30_action")
        self.day20_mid_day30_action.setStatusTip(u'股价在20,30日均线之间')               
        
        self.da_day10_action = QtGui.QAction(u'股价在10日均线之上',self,triggered = lambda :self.xuanGuCmd(4))
        self.da_day10_action.setObjectName("da_day10_action")
        self.da_day10_action.setStatusTip(u'股价在10日均线之上')  
        
        self.da_day20_action = QtGui.QAction(u'股价在20日均线之上',self,triggered = lambda :self.xuanGuCmd(5))
        self.da_day20_action.setObjectName("da_day20_action")
        self.da_day20_action.setStatusTip(u'股价在20日均线之上')             
        
        self.da_day30_action = QtGui.QAction(u'股价在30日均线之上',self,triggered = lambda :self.xuanGuCmd(6))
        self.da_day30_action.setObjectName("da_day30_action")
        self.da_day30_action.setStatusTip(u'股价在30日均线之上')     
        
        self.day5_mid_day10_da_day20_30_action = QtGui.QAction(u'股价在5,10日均线之间, 且大于20,30日均线',self,triggered = lambda :self.xuanGuCmd(7))
        self.day5_mid_day10_da_day20_30_action.setObjectName("day5_mid_day10_da_day20_30_action")
        self.day5_mid_day10_da_day20_30_action.setStatusTip(u'股价在5,10日均线之间, 且大于20,30日均线')     
        
        self.da_day5_nearest_action = QtGui.QAction(u'股价在5日均线附近, 且大于10,20日均线',self,triggered = lambda :self.xuanGuCmd(8))
        self.da_day5_nearest_action.setObjectName("da_day5_nearest_action")
        self.da_day5_nearest_action.setStatusTip(u'股价在5日均线附近, 且大于10,20日均线')     
        
        #self.xuangu_menu.setEnabled(False)
        self.xuangu_menu.addAction(self.day5_action)
        self.xuangu_menu.addAction(self.day5_mid_day10_da_day20_action)
        self.xuangu_menu.addAction(self.day10_mid_day20_action)
        self.xuangu_menu.addAction(self.day20_mid_day30_action)
        self.xuangu_menu.addAction(self.da_day10_action)
        self.xuangu_menu.addAction(self.da_day20_action)
        self.xuangu_menu.addAction(self.da_day30_action)
        self.xuangu_menu.addAction(self.day5_mid_day10_da_day20_30_action)
        self.xuangu_menu.addAction(self.da_day5_nearest_action)
        self.xuangu_menu.addSeparator()
    #----------------------------------------------------------------------
    def importData(self):
        """"""
        fileP= QtGui.QFileDialog.getOpenFileName(self, 
                                                    u'导入自选股', 
                                                    '', 
                                                    "*.txt;*.py", 
                                                    )
        if  fileP !='':
            f = open(unicode(fileP.toUtf8(),'utf-8','ignore'),'r')
            data = f.read()
            #print data
            f.close()
            self.data.clear()
            for x in data.split('==')[0].split(','):
                self.data.append(x)
            self.model.setStringList(self.data)
            self.label_xuanGuDate.setText(u'选股时间:%s'%' '.join(data.split('==')[1].split(' ')[-2:]))
            self.count_lab.setText(u"选出的股票数量:%d"%len(data.split('==')[0].split(',')))
        

    #----------------------------------------------------------------------
    def outPutData(self):
        """"""
        tiemstr = time.strftime('%Y%m%d_%H:%M:%S',time.localtime())
        fileP  = QtGui.QFileDialog.getSaveFileName(self,u'保存为自选股','',"*.py;*.txt",'%s.py'%tiemstr)
        st = unicode(self.data.join(',').toUtf8(),'utf-8','ignore')
        #d=[]
        #for  i in range(self.data.count()):
            #d.append(unicode(self.data.takeAt(i).toUtf8(),'utf-8','ignore'))        
        if fileP !='':
            f = open(unicode(fileP.toUtf8(),'utf-8','ignore'),'w')
            data = u'{0}'.format(st)
            f.write(data)   
            n= self.canShu.neiWai.value()
            z=self.canShu.zhuLi.value()
            s=self.canShu.huangShouLv.value()
            date = time.strftime('%Y/%m/%d %H:%M:%S',time.localtime())
            #print str(n).encode('utf-8')
            f.write('==内外盘: %f 主力资金:%f 换手率:%f 时间: %s'%(n,z,s,date))
            f.close()
        
    #激活菜单事件
    @QtCore.pyqtSignature("QPoint")    
    #----------------------------------------------------------------------
    def on_listWidget_customContextMenuRequested(self,point):
        """"""
        item = self.listWidget.indexAt(point)
        menu = QtGui.QMenu(self.listWidget)
        action = QtGui.QAction(u'添加股票',self,triggered=lambda : self.showDialog(item.row(),item))
        action.setObjectName('ddd')
        action1 = QtGui.QAction(u'删除股票',self,triggered=lambda:self.deleteitems())
        action1.setObjectName('fff')
        menu.addAction(action)
        menu.addAction(action1)
        menu.exec_(QtGui.QCursor.pos())
        #self.connect(action1, QtCore.SIGNAL('triggered()'), QtCore.SLOT(self.deleteitems(
                                                                           #item)))
        #self.connect(action, QtCore.SIGNAL('triggered()'),QtCore.SLOT(self.showDialog(item.row(), 
                                                                        #item)))
        
        #print item.data(item.row()).toString()        
    #----------------------------------------------------------------------
    def showDialog(self,low,item):
        """"""
        text, ok = QtGui.QInputDialog.getText(self, 'Input Dialog',
                                              'Enter your name:')
        #print self.sender
        if ok:
            d=self.data.insert(low,text)  
            self.model.setStringList(self.data)
            self.listWidget.setModel(self.model)
            self.count_lab.setText(u"选出的股票数量:%d"%len(self.data))
    #----------------------------------------------------------------------
    def deleteitems(self):
        """"""
        item = self.listWidget.currentIndex()
        self.data.removeAt(item.row())
        self.model.setStringList(self.data)   
        self.listWidget.setModel(self.model)
        self.count_lab.setText(u"选出的股票数量:%d"%len(self.data))        
        #button=QtGui.QMessageBox.question(self,u'删除',unicode(item.data(item.internalId()).toString(),'Utf8', 'ignore' ) ,QtGui.QMessageBox.Ok|QtGui.QMessageBox.Cancel, QtGui.QMessageBox.Ok)
        #if button==QtGui.QMessageBox.Ok:
            
            #self.data.removeAt(item.row())
            #self.model.setStringList(self.data)   
            #self.listWidget.setModel(self.model)
            #self.count_lab.setText("选出的股票数量:%d"%len(self.data))
            ##print 'ok',item.row(),
        #elif button==QtGui.QMessageBox.Cancel:
            #print 'Cancel'
        #else:
            #print 'pass'
            #return
    #----------------------------------------------------------------------
    def setStatusTipText(self):
        """"""
        self.label_daiMa.setStatusTip(self.label_daiMa.text())
        self.close_lab.setStatusTip(self.close_lab.text())
        self.new_lab.setStatusTip(self.new_lab.text())
        self.low_lab.setStatusTip(self.low_lab.text())
        self.high_lab.setStatusTip(self.high_lab.text())
        self.buy1_lab.setStatusTip(self.buy1_lab.text())
        self.sell1_lab.setStatusTip(self.sell1_lab.text())
        self.buy2_lab.setStatusTip(self.buy2_lab.text())
        self.sell2_lab.setStatusTip(self.sell2_lab.text())
        self.buy3_lab.setStatusTip(self.buy3_lab.text())
        self.sell3_lab.setStatusTip(self.sell3_lab.text())
    
        self.buy4_lab.setStatusTip(self.buy4_lab.text())
        self.sell4_lab.setStatusTip(self.sell4_lab.text())
        self.buy5_lab.setStatusTip(self.buy5_lab.text())
        self.sell5_lab.setStatusTip(self.sell5_lab.text())
        self.date_lab.setStatusTip(self.date_lab.text())
    
        self.time_lab.setStatusTip(self.time_lab.text())
        self.huanShouLv_lab.setStatusTip(self.huanShouLv_lab.text())
        self.zhangDie_lab.setStatusTip(self.zhangDie_lab.text())
        self.neiPan_lab.setStatusTip(self.neiPan_lab.text())
        self.waiPan_lab.setStatusTip(self.waiPan_lab.text())
        self.neiwaiPanBi_lab.setStatusTip(self.neiwaiPanBi_lab.text())
        self.zhuLiMai_lab.setStatusTip(self.zhuLiMai_lab.text())    
        self.open_lab.setStatusTip(self.open_lab.text())
        
    #----------------------------------------------------------------------
    def xuanGuCmd(self,xuanGuType):
        """"""
        s = unicode(self.sender().text().toUtf8(),'utf-8','ignore')
        QtGui.QMessageBox.about(self,u"选股策略>>%s"%s,u"选股分析中,请耐心等待5-6分钟")   
        self.setWindowTitle(u'%s  选股分析中...'%self.windowTitleText)
        stockCodeList=shanghaiAgu.stockCode1+zhongXiaoban.stockCode1+chuangyeban.stockCode1
        xuaguThreeding = bakeXuanGuThreeding(xuanGuType, stockCodeList, self)
        xuaguThreeding.update_date.connect(self.butthonCmd)
        xuaguThreeding.start()
    #----------------------------------------------------------------------
    def labelClink(self, datatype):
        """"""
        self.ctiveCmd(datatype)
        self.isCheck = datatype
        #print self.isCheck
    #----------------------------------------------------------------------
    def buttonCmd(self):
        """"""
        self.setWindowTitle(u'%s  下载数据...'%self.windowTitleText)
        huanShouLv = self.canShu.huangShouLv.value()
        zhuLiLiuRu = self.canShu.zhuLi.value()
        neiWaiPanBi =self.canShu.neiWai.value()        
        btcmd = BUpdataThreedingButton(huanShouLv,zhuLiLiuRu,neiWaiPanBi,self)
        btcmd.update_date.connect(self.butthonCmd)
        btcmd.start()
        #self.setWindowTitle(self.windowTitleText)
    #----------------------------------------------------------------------
    def butthonCmd(self,data, *args):
        """"""
        #print data
        #self.setWindowTitle(u'%s  下载数据...'%self.windowTitle())
        #clsData = pandasStock.pandasStock()
        #clsData.huanShouLv = self.canShu.huangShouLv.value()
        #clsData.zhuLiLiuRu = self.canShu.zhuLi.value()
        #clsData.neiWaiPanBi =self.canShu.neiWai.value()
        ##print clsData.huanShouLv,clsData.zhuLiLiuRu,clsData.neiWaiPanBi
        #self.pandasData =  clsData.main()
        #self.data = QtCore.QStringList()
        #for x in self.pandasData['neiWaiPanBi_zhuLiLiuRu_huanShouLv'].index:
            ##print x
            #self.data.append(x) 
        
        #self.data.append()
        self.data=data
        self.model.setStringList(self.data)     #=  QtGui.QStringListModel(self.data)
        self.listWidget.setModel(self.model)
        self.count_lab.setText(u"选出的股票数量:%d"%len(self.data))
        #self.cView.tableView.setModel(self.data)
        self.setWindowTitle(self.windowTitleText)
        self.label_xuanGuDate.setText(u'选股时将:%s'%time.strftime('%Y/%m/%d %H:%M:%S',time.localtime()))
        
    #----------------------------------------------------------------------
    def doub(self, *args):
        """"""
        string =  self.listWidget.selectedIndexes()
        
        #print string[0].column(), string[0].row()
    #----------------------------------------------------------------------
    def ctiveCmd(self, datatype, *args):
        """"""
        if datatype=='':
            datatype=self.isCheck
        cor =  self.listWidget.currentIndex()  
        code = cor.data(cor.internalId()).toString()
        if code =='':
            self.listWidget.setCurrentIndex(self.model.index(0, 0))
            cor =  self.listWidget.currentIndex()  
            code = cor.data(cor.internalId()).toString()            
        clsData = pandasStock.pandasStock()
        if code.startsWith ('30') or  code.startsWith ('00'):
            code = u'sz{0}'.format(code)
        elif code.startsWith ('60'):
            code = u'sh{0}'.format(code)
        
        datas =  clsData.datas(allStockCode = False, stockCodes=[code])
        datasM =  clsData.moneyDatas(allStockCode = False, stockCodes=[code])
        if not datas.empty and not datasM.empty:
            datas[u'主力净流入资金流入流出总和'] = datasM[u'主力净流入资金流入流出总和']
            datas[u'内外比'] = ((datas[ u'外盘'] - datas[ u'内盘']) / (datas[ u'外盘'] + datas[ u'内盘'])) * 100
            #print datas
            self.setLable(datas)
            try:
                f = 'rc/%s_%s.png'%(code,datatype)
                if os.path.exists(f):
                    self.statusBar().showMessage(u'有图片:%s'%f)
                    mtime = time.ctime(os.path.getmtime(f.name)) #修改时间
                    ctime = time.strftime("%Y-%m-%d %H:%M:%S",time.gmtime(os.path.getmtime(f.name)))
                    if utility.Caltime(ctime,time.strftime("%Y-%m-%d %H:%M:%S",time.localtime())) < 50:
                        print 'downImage>>>>>>>'
                        pixamp = QtGui.QPixmap( 'rc/%s_%s.png'%(code,datatype))#unicode(filePath, 'gbk', 'ignore' ) + '/rc/%s_%s.png'%(code,datatype))
                        pixamp.scaled(QtCore.QSize(20, 30))
                        pixamp.setMask(pixamp.mask())
                        self.image.setPixmap(pixamp)  
                        self.image.setScaledContents(True)
                    else:
                        img = downGifThreeding(code, datatype,self)
                        img.update_date.connect(self.getGif)
                        img.start() 
                else:
                    self.statusBar().showMessage(u'没有图片:%s'%f)
                    img = downGifThreeding(code, datatype,self)
                    img.update_date.connect(self.getGif)
                    img.start()                     
            except:
                #print 'rr'
                img = downGifThreeding(code, datatype,self)
                img.update_date.connect(self.getGif)
                img.start()
        else:
            txt=unicode(self.label_daiMa.text().toUtf8(), 'Utf8', 'ignore' ).split(':')[0]
            self.label_daiMa.setText(u'%s:%s 停牌'%(txt,code))
            self.statusBar().showMessage(u'%s 停牌'%code)
        self.count_lab.setText(u"选出的股票数量:%d"%len(self.data))
        self.setStatusTipText()
        #print (u'刷新数据...')
    #----------------------------------------------------------------------
    def setLable(self, datas):
        """"""
        colums = datas.columns
        for l, d in  zip(self.lable, [5, 4, 3, 33, 34, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 30, 38, 32, 8, 7, 49, 50,37,29]):
            t = datas[colums[d]]
            text =  l.text()
            text = unicode(text.toUtf8(), 'Utf8', 'ignore' )
            #print d, text, datas[colums[d]].iloc[0]
            if d in [9, 11, 13, 15, 17, 19, 21, 23, 25, 27] :
                l.setText(u"{0}:{1}  {2}".format(text.split(':')[0] , datas[colums[d]].iloc[0], int(datas[colums[d+1]].iloc[0])))
            else:
                if d == 30:
                    l.setText(u"{0}".format(time.strftime('%Y/%m/%d %H:%M:%S',time.strptime(str(datas[colums[d]].iloc[0]),'%Y%m%d%H%M%S'))))
                    #print type(datas[colums[d]].iloc[0])
                elif d == 37:
                    l.setText(u"{0}:{1}".format(text.split(':')[0] , datas[colums[d]].iloc[0]/10000))
                elif d== 29:
                    ss = datas[colums[d]].iloc[0].split('|')
                    ss.reverse()
                    l.setText(u"{0}:\n{1}".format(text.split(':')[0] , '\n'.join(ss).replace('/' ,' ')))
                    
                else:
                    l.setText(u"{0}:{1}".format(text.split(':')[0] , datas[colums[d]].iloc[0]))
            if datas[colums[32]].iloc[0] > 0.0:
                l.setStyleSheet("color: rgb(255, 0, 0);")
            else:
                l.setStyleSheet("color: rgb(0, 255, 0);")
        text =  self.label_daiMa.text()
        text = unicode(text.toUtf8(), 'Utf8', 'ignore' )
        self.label_daiMa.setText(u"{0}:{1}".format(text.split(':')[0] , datas[colums[1]].iloc[0]))
    #----------------------------------------------------------------------
    def getGif(self,ImagePath):
        """"""
        pixamp = QtGui.QPixmap(ImagePath.replace('.gif', '.png'))
        pixamp.scaled(QtCore.QSize(20, 30))
        pixamp.setMask(pixamp.mask())
        self.image.setPixmap(pixamp)  
        self.image.setScaledContents(True)
    #----------------------------------------------------------------------
    def getGif1(self, stockCode = '', datatype = 'min'):
        """
        stockCode : 股票代码    sh600000
        datatype  : min  分时  daily 日线  weekly 周线 
        """
        if datatype in ['min', 'daily', 'weekly', 'monthly']:
            imgUrl = "http://image.sinajs.cn/newchart/" + datatype + "/n/"  + stockCode + ".gif"
            url = urllib.urlopen(imgUrl)
            path =  'rc/'
            if os.path.exists(path):
                pathF =  'rc/' + imgUrl.split('/')[-1]
            else:
                os.mkdir(path)
                pathF =  'rc/' + imgUrl.split('/')[-1]
            #imgfile = open(path, 'wb')
            #imgfile.write(url.read())
            #imgfile.close()
            req = requests.get(imgUrl)
            img_buff = StringIO(req.content)
            img = Image.open(img_buff)
            h, w = img.size
            #img.thumbnail((h*0.9, w * 0.9), Image.ANTIALIAS)  
            #print path
            img.save(pathF.replace('.gif', '.png'), 'png')

            pixamp = QtGui.QPixmap(pathF.replace('.gif', '.png'))
            pixamp.scaled(QtCore.QSize(20, 30))
            pixamp.setMask(pixamp.mask())
            self.image.setPixmap(pixamp)
            self.image.setScaledContents(True)
########################################################################
class downGifThreeding(QtCore.QThread):
    """"""
    #声明一个信号，同时返回一个str，
    update_date = QtCore.pyqtSignal(str)
    #----------------------------------------------------------------------
    def __init__(self,stockCode,datatype,parent=None):
        """"""
        super(downGifThreeding,self).__init__(parent)
        self.stockCode= stockCode
        self.datatype = datatype

    #----------------------------------------------------------------------
    def run(self,*args):
        """
        stockCode : 股票代码    sh600000
        datatype  : min  分时  daily 日线  weekly 周线 
        """
        if self.datatype in ['min', 'daily', 'weekly', 'monthly']:
            imgUrl = "http://image.sinajs.cn/newchart/" + self.datatype + "/n/"  +self.stockCode + ".gif"
            url = urllib.urlopen(imgUrl)
            path =   'rc/'
            if os.path.exists(path):
                pathF =   'rc/' + imgUrl.split('/')[-1]
            else:
                os.mkdir(path)
                pathF =  'rc/' + imgUrl.split('/')[-1]
            req = requests.get(imgUrl)
            img_buff = StringIO(req.content)
            img = Image.open(img_buff)
            h, w = img.size
            #img.thumbnail((h*0.9, w * 0.9), Image.ANTIALIAS)  
            #print path
            img.save(pathF.replace('.gif', '%s_%s.png'%(self.stockCode,self.datatype)), 'png')
            self.update_date.emit(pathF.replace('.gif', '%s_%s.png'%(self.stockCode,self.datatype)))

    
#----------------------------------------------------------------------
########################################################################
class backendUpdataThreeding(QtCore.QThread):
    """"""
    #声明一个信号，同时返回一个str，
    update_date = QtCore.pyqtSignal(str)
    #----------------------------------------------------------------------
    def __init__(self,parent=None):
        """"""
        super(backendUpdataThreeding,self).__init__(parent)
        self.isCheck=''
    #----------------------------------------------------------------------
    def setCheck(self,isCheck):
        """"""
        self.isCheck=isCheck
    #----------------------------------------------------------------------
    def run(self,*args):
        """Constructor"""
        while True:
            #print time.strftime('%Y%m%d %H:%M:%S',time.localtime())<time.strftime('%Y%m%d 15:05:00',time.localtime())
            print 'updata_date'
            if time.localtime().tm_wday not in [5,6]:
                if time.strftime('%Y%m%d %H:%M:%S',time.localtime()) < time.strftime('%Y%m%d 15:05:00',time.localtime()):
                    self.update_date.emit(self.isCheck)
                    time.sleep(3.5)
                else:
                    self.update_date.emit(self.isCheck)
                    #time.sleep(3.5)                      
                    break
            else:
                self.update_date.emit(self.isCheck)
                time.sleep(3.5)                
                break
class BUpdataThreedingButton(QtCore.QThread):
    """"""
    update_date = QtCore.pyqtSignal(QtCore.QStringList)
    #----------------------------------------------------------------------
    def __init__(self,huanShouLv,zhuLiLiuRu,neiWaiPanBi,parent=None):
        """"""
        super(BUpdataThreedingButton,self).__init__(parent)
        self.huanShouLv=huanShouLv
        self.zhuLiLiuRu=zhuLiLiuRu
        self.neiWaiPanBi=neiWaiPanBi
    #----------------------------------------------------------------------
    def run(self,*args):
        """Constructor"""
        clsData = pandasStock.pandasStock()
        clsData.huanShouLv = self.huanShouLv
        clsData.zhuLiLiuRu = self.zhuLiLiuRu
        clsData.neiWaiPanBi =self.neiWaiPanBi
        pandasData =  clsData.main()
        data = QtCore.QStringList()
        #print pandasData['neiWaiPanBi_zhuLiLiuRu_huanShouLv'][u'代码']
        for x in pandasData['neiWaiPanBi_zhuLiLiuRu_huanShouLv'].index:
            #print str(x),type(x)
            data.append(str(x))         
        self.update_date.emit(data)
class bakeXuanGuThreeding(QtCore.QThread):
    """"""
    update_date = QtCore.pyqtSignal(QtCore.QStringList)
    #----------------------------------------------------------------------
    def __init__(self,xuanGuType,stockCodeList=[],parent=None):
        """xuanGuType 选股方式"""
        super(bakeXuanGuThreeding,self).__init__(parent)
        self.xuanGuType = xuanGuType
        self.stockCodeList=stockCodeList
    #----------------------------------------------------------------------
    def run(self,*args):
        """Constructor"""
        clsData = pandasStock.pandasStock()
        pandasData =  clsData.xuanGu_KLine(self.stockCodeList)   #{'da_day5':[],'day5_mid_day10_da_day20': [],"day10_mid_day20":[],'day20_mid_day30':[],'da_day10':[],'da_day20':[],'da_day30':[]}
        result = ''
        if self.xuanGuType==0:
            result= 'da_day5'
        elif self.xuanGuType==1:
            result= 'day5_mid_day10_da_day20'     
        elif self.xuanGuType==2:
            result= 'day10_mid_day20'     
        elif self.xuanGuType==3:
            result= 'day20_mid_day30'  
        elif self.xuanGuType==4:
            result= 'da_day10' 
        elif self.xuanGuType==5:
            result= 'da_day20' 
        elif self.xuanGuType==6:
            result= 'da_day30'   
        elif self.xuanGuType==7:
            result= 'day5_mid_day10_da_day20_30'   
        elif self.xuanGuType==8:
            result= 'da_day5_nearest'               
            
        data = QtCore.QStringList()
        for x in pandasData[result]:
            #print x
            data.append(x[2:])         
        self.update_date.emit(data)
########################################################################
class  checkThreeding(QtCore.QThread):#threading.Thread):
    """"""
    #update_date = QtCore.pyqtSignal(str)
    def __init__(self,QMenuBar,parent=None):
        super(checkThreeding,self).__init__(parent)
        self.QMenuBar = QMenuBar
        self.parent = parent
    #----------------------------------------------------------------------
    def run(self):
        """"""
        #filePath =  os.path.dirname(__file__).replace('\\', '/')
        #history_DataPath = '{0}/history/'.format(filePath)
        history_DataPath = 'history/'
        #print history_DataPath
        if not os.path.exists(history_DataPath):
            os.mkdir(history_DataPath)  
        self.QMenuBar.setEnabled(False)
        if os.path.exists(history_DataPath+"sh600000_daily.csv"):
            f = open(history_DataPath+"sh600000_daily.csv",'r')
            ff = f.readlines()[-1]  
            date = ff.split(' ')[0]
            print type(date),'.......'
            import time
            d = time.strptime(str(date),'%Y%m%d')
            print d.tm_wday
            if d.tm_wday in [0,1,2,3,4]:
                #print 'run here',time.localtime().tm_wday
                if time.localtime().tm_wday not in [5,6]:
                    print time.localtime().tm_wday
                    if  time.localtime().tm_yday -d.tm_yday>1:
                        self.parent.statusBar().showMessage('checkThreeding')
                        print u'>>>>>>>下载历史数据....'
                        getStockData.allHistory(shanghaiAgu.stockCode1+zhongXiaoban.stockCode1+chuangyeban.stockCode1)
                        self.QMenuBar.setEnabled(True)
                    else:
                        self.QMenuBar.setEnabled(True)
                else:
                    self.QMenuBar.setEnabled(True)                
            else:
                self.QMenuBar.setEnabled(True)            
        else:
            #print filePath,'history_DataPath'
            print u'下载历史数据....'
            self.parent.statusBar().showMessage('checkThreeding:%s'%history_DataPath)
            getStockData.allHistory(shanghaiAgu.stockCode1+zhongXiaoban.stockCode1+chuangyeban.stockCode1)
            self.QMenuBar.setEnabled(True)
        #self.update_date.emit('')
        
########################################################################
class backendDownGifThreeding(QtCore.QThread):
    """"""
    #声明一个信号，同时返回一个str，
    update_date = QtCore.pyqtSignal(str)
    #----------------------------------------------------------------------
    def __init__(self,QListView ,parent=None):
        """"""
        super(backendDownGifThreeding,self).__init__(parent)
        self.QListView=QListView
    #----------------------------------------------------------------------
    def run(self,*args):
        """Constructor"""
        while True:
            #print time.strftime('%Y%m%d %H:%M:%S',time.localtime())<time.strftime('%Y%m%d 15:05:00',time.localtime())
            model= self.QListView.model()
            index = model.rowCount(QtCore.QModelIndex())
            QStringList = model.stringList()
            
            self.stockCodeList=[]
            for i in QStringList.join(',').split(','):
                if  i !=None:
                    code = unicode(i.toUtf8(),'utf-8','ignore')
                    if code.startswith (u'30') or  code.startswith (u'00'):
                        code = u'sz{0}'.format(code)
                    elif code.startswith ('60'):
                        code = u'sh{0}'.format(code) 
                    self.stockCodeList.append(code)
            if len(self.stockCodeList)!=0:
                for stockCode in self.stockCodeList:
                    for datatype in ['min', 'daily', 'weekly', 'monthly']:
                        imgUrl = "http://image.sinajs.cn/newchart/" + datatype + "/n/"  +stockCode + ".gif"
                        url = urllib.urlopen(imgUrl)
                        path =  'rc/'
                        if os.path.exists(path):
                            pathF =  'rc/' + imgUrl.split('/')[-1]
                        else:
                            os.mkdir(path)
                            pathF =  'rc/' + imgUrl.split('/')[-1]
                        req = requests.get(imgUrl)
                        img_buff = StringIO(req.content)
                        img = Image.open(img_buff)
                        h, w = img.size
                        #img.thumbnail((h*0.9, w * 0.9), Image.ANTIALIAS)  
                        #print pathF.replace('.gif', '_%s.png'%datatype)
                        img.save(pathF.replace('.gif', '_%s.png'%datatype), 'png')
                        self.update_date.emit(pathF.replace('.gif', '_%s.png'%datatype))   
            else:
                continue
            time.sleep(2)
            
#----------------------------------------------------------------------
def main():
    """"""
    app = QtGui.QApplication(sys.argv)
    win =  ui()
    win.show()
    
    gif = backendDownGifThreeding(win.listWidget,win)
    gif.update_date.connect(lambda *args :'')
    gif.start()   
    
    his = checkThreeding(win.xuangu_menu,win)
    #his.update_date.connect(lambda *args :'')
    his.start()
    
    sys.exit(app.exec_())    
    
if __name__ == '__main__':
    main()
    #print modPath

