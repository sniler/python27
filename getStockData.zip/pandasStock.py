#!/usr/bin/env python
#coding:utf-8
#scriptName: pandasStock.py

import getStockData
import os , sys, datetime, time
import xlrd, xlwt
import pandas as pd
import numpy as np
import sqlite3
import shanghaiAgu, zhongXiaoban, chuangyeban
import utility
path = os.path.dirname(__file__).replace('\\', '/')
#from scripts import xuanGuCelue
# 
#
sqlPath_NewData = '{0}/data/dataBaseP.db'.format(path)
if not os.path.exists(os.path.dirname(sqlPath_NewData)):
    os.mkdir(os.path.dirname(sqlPath_NewData))
stockCode =  shanghaiAgu.stockCode1 + zhongXiaoban.stockCode1
########################################################################
class pandasStock(object):
    """"""

    #----------------------------------------------------------------------
    def __init__(self):
        """Constructor"""
        self.huanShouLv = 4.0
        self.maiMaiYiBi = 10.0
        self.zhuLiLiuRu = 5.0
        self.zhangFu = 0.0
        self.xianJia = 8.0
        self.neiWaiPanBi = 20.0
        self.chengJiaoLiang = 100000.0
        self.shiJingLv=0.1
        self.shiYingLv=0.2
        self.zongShiZhi=1000000
        self.columns = getStockData.getStockNewData().missage
        self.columnsMoney = getStockData.getStockMoney().missage
        pass
    
    #----------------------------------------------------------------------
    @classmethod
    def datas(cls,stockCodes = None, allStockCode = True):
        """"""
        data = getStockData.getStockNewData()
        columns = data.missage.values()
        outData = pd.DataFrame(columns = columns)#range(len(data.missage.values())))
        
        if allStockCode == True:
            if stockCodes == None:
                for x in range(0, len(stockCode), 40):
                    o =  data.getDataMorePandas(stockCode[x:x+40])
                    if o[0][3] != 0.0:
                        pdData = pd.DataFrame(o , dtype=None, copy=False)
                        pdDataout = pdData.T  
                        pdDataout.columns=columns
                        #print outData,pdDataout
                        outData = pd.merge(outData, pdDataout, how='outer', indicator=False)
                    else:
                        pass
        else:
            if isinstance(stockCodes, str):
                stockCodes = [stockCodes]
            if stockCodes != None:
                o =  data.getDataMorePandas(stockCodes)
                if o[0][3] != 0.0:
                    pdData = pd.DataFrame(o , dtype=None, copy=False)
                    pdDataout = pdData.T 
                    pdDataout.columns=columns
                    outData = pd.merge(outData, pdDataout, how='outer' , indicator=False)
                else:
                    pass
        outData.columns = columns
        outData.index = outData[columns[2]]
        
        return outData.dropna()
    
    #----------------------------------------------------------------------
    @classmethod
    def moneyDatas(cls, stockCodes = None, allStockCode = True):
        """"""
        dataMoney = getStockData.getStockMoney()
        columns = dataMoney.missage.values()
        outData = pd.DataFrame(columns = columns)#range(len(dataMoney.missage.keys())))
        if allStockCode == True:
            if  stockCodes == None:
                for x in range(0, len(stockCode), 40):
                    o =  dataMoney.getDataMorePandas(stockCode[x:x+40])
                    if o[0]!={}:
                        if o[0][3] != 0.0:
                            pdData = pd.DataFrame(o , dtype=None, copy=False)
                            pdDataout = pdData.T 
                            pdDataout.columns = columns
                            outData = pd.merge(outData, pdDataout, how='outer', indicator=False)
                        else:pass
        else:
            if isinstance(stockCodes, str):
                stockCodes = [stockCodes]
            if stockCodes != None:
                o =  dataMoney.getDataMorePandas(stockCodes)
                if o[0] != {}:
                    if o[0][3] !=0.0:
                        pdData = pd.DataFrame(o , dtype=None, copy=False)
                        pdDataout = pdData.T  
                        pdDataout.columns = columns
                        outData = pd.merge(outData, pdDataout, how='outer', indicator=False)
                    else:pass
        outData.columns = columns
        outData.index = outData[columns[14]]

        return outData.dropna()
    #----------------------------------------------------------------------
    def xuanGu1(self):
        """"""
        dataAll =  self.data                      #pandasStock.datas()
        #neiWaiPanBi
        neiWaiPanBi =  dataAll[((dataAll[self.columns[7]] -dataAll[self.columns[8]])/(dataAll[self.columns[7]] +dataAll[self.columns[8]]) )*100 > self.neiWaiPanBi ]
        #zhuLiLiuRu
        dataM   =   self.dataMoney                #pandasStock.moneyDatas()
        zhuLiLiuRu =  dataM[dataM[self.columnsMoney[4]] >= self.zhuLiLiuRu]
        #print zhuLiLiuRu
        outData =  neiWaiPanBi[neiWaiPanBi.index.isin(zhuLiLiuRu.index)]
        outDataMoney =  zhuLiLiuRu[zhuLiLiuRu.index.isin(neiWaiPanBi.index)]
        outData[self.columnsMoney[4]] = outDataMoney[self.columnsMoney[4]]
        
        return outData
    #----------------------------------------------------------------------
    def xuanGu(self,neiWaiPanBiCheck=True,zhuLiLiuRuCheck=True,huanShouLvCheck=True, zhangFuCheck=False, xianJiaCheck=False, shiJingLvCheck=False, shiYingLvCheck=False, zongShiZhiCheck=False):
        """"""
        dataAll =  self.data                      #pandasStock.datas()
        dataM   =   self.dataMoney                #pandasStock.moneyDatas()
        #内外盘比
        dataAll[u'内外盘比率'] = ((dataAll[self.columns[7]] -dataAll[self.columns[8]])/(dataAll[self.columns[7]] +dataAll[self.columns[8]]) )*100
        #neiWaiPanBi =  dataAll[((datAll[self.columns[7]] -dataAll[self.columns[8]])/(dataAll[self.columns[7]] +dataAll[self.columns[8]]) )*100 > self.neiWaiPanBi ]
        neiWaiPanBi =  dataAll[dataAll[u'内外盘比率'] >= self.neiWaiPanBi ]
        #主力流入
        zhuLiLiuRu =  dataM[dataM[self.columnsMoney[4]] >= self.zhuLiLiuRu]
        #换手率
        huanShouLv = dataAll[dataAll[self.columns[38]] >= self.huanShouLv]
        #涨跌幅
        zhangFu = dataAll[dataAll[self.columns[32]] >= self.zhangFu]
        #当前价格
        xianJia = dataAll[dataAll[self.columns[3]] >= self.xianJia]
        #市净率 一般指标低风险小
        shiJingLv = dataAll[dataAll[self.columns[46]] >= self.shiJingLv]
        #市盈率
        shiYingLv = dataAll[dataAll[self.columns[39]] >= self.shiYingLv]
        #总市值
        zongShiZhi = dataAll[dataAll[self.columns[45]] >= self.zongShiZhi]

        result = {}
        #  0  neiWaiPanBi
        if neiWaiPanBiCheck == True:
            result['neiWaiPanBi'] = neiWaiPanBi
        else:
            result['neiWaiPanBi'] = None
        #  1  zhuLiLiuRu
        if zhuLiLiuRuCheck == True:
            result['zhuLiLiuRu'] = zhuLiLiuRu
        else:
            result['zhuLiLiuRu'] = None
        #  2
        if huanShouLvCheck == True:
            result['huanShouLv'] = huanShouLv
        else:
            result['huanShouLv'] = None
        #  3
        if zhangFuCheck == True:
            result['zhangFu'] = zhangFu
        else:
            result['zhangFu'] = None
        #  4
        if xianJiaCheck == True:
            result['xianJia'] = xianJia
        else:
            result['xianJia'] = None
        #  5
        if shiJingLvCheck == True:
            result['shiJingLv'] = shiJingLv
        else:
            result['shiJingLv'] = None
        #  6
        if shiYingLvCheck == True:
            result['shiYingLv'] = shiYingLv
        else:
            result['shiYingLv'] = None

        #  7
        if zongShiZhiCheck == True:
            result['zongShiZhi'] = zongShiZhi
        else:
            result['zongShiZhi'] = None
        #  8  开始复合选择
        if neiWaiPanBiCheck == True and zhuLiLiuRuCheck == True:
            outData1 =  neiWaiPanBi[neiWaiPanBi.index.isin(zhuLiLiuRu.index)]
            outDataMoney1 =  zhuLiLiuRu[zhuLiLiuRu.index.isin(neiWaiPanBi.index)]
            outData1[self.columnsMoney[4]] = outDataMoney1[self.columnsMoney[4]]
            result['neiWaiPanBi_zhuLiLiuRu'] = outData1
        else:
            result['neiWaiPanBi_zhuLiLiuRu'] = None
        #  9
        if neiWaiPanBiCheck == True and zhuLiLiuRuCheck == True and huanShouLvCheck == True:
            neiWaiPanBi = neiWaiPanBi[neiWaiPanBi[self.columns[38]]>self.huanShouLv]
            outData =  neiWaiPanBi[neiWaiPanBi.index.isin(zhuLiLiuRu.index)]
            outDataMoney =  zhuLiLiuRu[zhuLiLiuRu.index.isin(neiWaiPanBi.index)]
            outData[self.columnsMoney[4]] = outDataMoney[self.columnsMoney[4]]
            result['neiWaiPanBi_zhuLiLiuRu_huanShouLv'] = outData
        else:
            result['neiWaiPanBi_zhuLiLiuRu_huanShouLv'] = None
        #   10

        return result
    #----------------------------------------------------------------------
    def xuanGu_KLine(self, stockCode):
        """"""
        #1 获取日交易数据，保存到本地 2 添加最新的数据 3 计算价格在10日均线之上的股票
        da_day5 = []
        da_day10 = []
        da_day20 = []
        da_day30 = []
        day5_mid_day10_da_day20 = []
        day10_mid_day20 = []
        day20_mid_day30 = []
        day5_mid_day10_da_day20_30 = []
        da_day5_nearest = []
        newD = getStockData.getStockNewData()
        for i in stockCode:
            if time.localtime().tm_wday not in [5,6]:
                dd = newD.getDataMore([i])  #newD.getDataMore([stockCode])
                if len(dd) !=0:
                    if dd[0][3]!=0.0:#过滤停牌的股票
                        newData = [dd[0][30][1][2:8], float(dd[0][5][1]), float(dd[0][3][1]), float(dd[0][33][1]), float(dd[0][34][1]), float(dd[0][36][1])]
                        columns = ['data', 'open', 'close', 'high', 'low', 'volomn']
                        pt = '%s/history/%s_daily.csv'%(path, i)
                        if not os.path.exists(pt):
                            getStockData.allHistory([i])
                        try:
                            f = pd.read_csv('%s/history/%s_daily.csv'%(path, i), sep=' ', names =columns,parse_dates=True)
                            #print time.localtime().tm_wday , '==========================================================='
                            if float(newData[0]) != f.loc[f.shape[0]-1][0]:
                                f.loc[f.shape[0]+1] = newData 
                                
                            f['5d'] = pd.rolling_mean(f['close'], window=5)
                            f['10d'] = pd.rolling_mean(f['close'], window=10)
                            f['20d'] = pd.rolling_mean(f['close'], window=20)
                            f['30d'] = pd.rolling_mean(f['close'], window=30)
                            f.fillna(0.0 , inplace=True)
                            #d5 = f[f['5d'] > f['10d']]
                            #d10 = d5[d5['10d'] > d5['20d']]
                            #print f[ (f['close'] > f['5d'])]
                            new = f.loc[f.shape[0]]
                            if  new['5d'] > new['close'] > new['10d'] > new['20d']:  #股价在5,10天之间, 且大于20天均线
                                day5_mid_day10_da_day20.append(i)
                            if  new['10d'] > new['close'] > new['20d'] :  #股价在10,20天之间, 且大于20天均线
                                day10_mid_day20.append(i)
                            if  new['20d'] > new['close'] > new['30d'] :  #股价在20,30天之间, 且大于20天均线
                                day20_mid_day30.append(i)       
                            if  new['close'] > new['5d'] :  #股价大于5天均线
                                da_day5.append(i)            
                            if  new['close'] > new['10d'] :  #股价大于10天均线
                                da_day10.append(i)
                            if  new['close'] > new['20d'] :  #股价大于20天均线
                                da_day20.append(i)
                            if new['30d'] < new['close'] :  #股价大于30天均线
                                da_day30.append(i)
                            if  new['5d'] > new['close'] > new['10d'] > new['20d']>new['30d']:  #股价在5,10天之间, 且大于20天均线
                                day5_mid_day10_da_day20_30.append(i)  
                            #print ((new['close'] - new['5d'])/(new['close'] + new['5d']))*100
                            if  -0.1 < ((new['close'] - new['5d'])/(new['close'] + new['5d'])) * 100< 0.1 and new['close']>new['10d']>new['20d']:  #股价在5日均线附近，偏差0.01,且股价大于10，20均线
                                da_day5_nearest.append(i)                          
                        except: 
                            pass
            else:
                #print time.localtime().tm_wday , '>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>'
                columns = ['data', 'open', 'close', 'high', 'low', 'volomn']
                pt = '%s/history/%s_daily.csv'%(path, i)
                if not os.path.exists(pt):
                    print u'没有文件'
                    flag = getStockData.allHistory([i])
                    if flag[i]!=True:
                        continue
                else:pass
                fl = pd.read_csv('%s/history/%s_daily.csv'%(path, i), sep=' ', names =columns,parse_dates=True)
                dd = newD.getDataMore([i])
                ftime =time.strftime('%Y-%m-%d %H:%M:%S',time.strptime( str(fl['data'][fl.shape[0]-1]),'%Y%m%d'))
                #print ftime,time.strftime("%Y-%m-%d %H:%M:%S",time.localtime())
                t = utility.Caltime(ftime, time.strftime("%Y-%m-%d %H:%M:%S",time.localtime()))     
                if t.days >= 3:
                    flag = getStockData.allHistory([i])
                    print u'下载历史>>>>>>>>>>>>>>>>'
                if len(dd) !=0:
                    if dd[0][3]!=0.0:#过滤停牌的股票
                        newData = [dd[0][30][1][2:8], float(dd[0][5][1]), float(dd[0][3][1]), float(dd[0][33][1]), float(dd[0][34][1]), float(dd[0][36][1])]    
                        f = pd.read_csv('%s/history/%s_daily.csv'%(path, i), sep=' ', names =columns,parse_dates=True)
                        #print f.shape[0]-1
                        ftime =time.strftime('%Y-%m-%d %H:%M:%S',time.strptime( str(f['data'][f.shape[0]-1]),'%Y%m%d'))
                        #print ftime,time.strftime("%Y-%m-%d %H:%M:%S",time.localtime())
                        t = utility.Caltime(ftime, time.strftime("%Y-%m-%d %H:%M:%S",time.localtime()))
                        print t
                        if t.days <= 3:
                            f['5d'] = pd.rolling_mean(f['close'], window=5)
                            f['10d'] = pd.rolling_mean(f['close'], window=10)
                            f['20d'] = pd.rolling_mean(f['close'], window=20)
                            f['30d'] = pd.rolling_mean(f['close'], window=30)
                            f.fillna(0.0,inplace=True)
                            #d5 = f[f['5d'] > f['10d']]
                            #d10 = d5[d5['10d'] > d5['20d']]
                            #print f.loc[f.shape[0]-1]
                            new = f.loc[f.shape[0]-1]
                            if  new['5d'] > new['close'] > new['10d'] > new['20d']:  #股价在5,10天之间, 且大于20天均线
                                day5_mid_day10_da_day20.append(i)
                            if  new['10d'] > new['close'] > new['20d'] :  #股价在10,20天之间, 且大于20天均线
                                day10_mid_day20.append(i)
                            if  new['20d'] > new['close'] > new['30d'] :  #股价在20,30天之间, 且大于20天均线
                                day20_mid_day30.append(i)       
                            if  new['close'] > new['5d'] :  #股价大于5天均线
                                da_day5.append(i)            
                            if  new['close'] > new['10d'] :  #股价大于10天均线
                                da_day10.append(i)
                            if  new['close'] > new['20d'] :  #股价大于20天均线
                                da_day20.append(i)
                            if  new['close'] > new['30d'] :  #股价大于30天均线
                                #print new['30d'] ,'+++++++++++++++++++++++++++++++++'
                                da_day30.append(i)
                            if  new['5d'] > new['close'] > new['10d'] > new['20d']>new['30d']:  #股价在5,10天之间, 且大于20天均线
                                day5_mid_day10_da_day20_30.append(i)   
                            #print ((new['close'] - new['5d'])/(new['close'] + new['5d'])) * 100
                            if  -0.1 < ((new['close'] - new['5d'])/(new['close'] + new['5d'])) * 100< 0.1  and new['close']>new['10d']>new['20d']:  #股价在5日均线附近，偏差0.01,且股价大于10，20均线
                                da_day5_nearest.append(i)    
                        else:pass
        return {'da_day5': da_day5, 'day5_mid_day10_da_day20': day5_mid_day10_da_day20,
                "day10_mid_day20": day10_mid_day20,'day20_mid_day30': day20_mid_day30,
                'da_day10': da_day10, 'da_day20': da_day20, 'da_day30': da_day30,'day5_mid_day10_da_day20_30':day5_mid_day10_da_day20_30,'da_day5_nearest':da_day5_nearest}
    
    #----------------------------------------------------------------------
    def writeNewDateTo_sql(self):
        """批量些数据库"""
        start =  datetime.datetime.now()
        print u'下载数据...'
        outData = self.datas()
        outDataM = self.moneyDatas()

        for n, i in enumerate(outDataM.columns):

            if i not in [outDataM.columns[0], outDataM.columns[12], outDataM.columns[14]]:
                outData[i] = outDataM[i]
        print u'链接数据库...'
        con = sqlite3.connect(sqlPath_NewData)
        cu = con.cursor()

        sql = []
        start1 =  datetime.datetime.now()
        print u'写入数据库...'
        for i in outData.index:
            code = ''
            if i.startswith('0') or i.startswith('3'):code = 'sz{}'.format(i)
            if i.startswith('6'):code = 'sh{}'.format(i)
            st = '''create table if not exists {0}(code,名字,代码,当前价格,昨收,今开,成交量手,外盘,内盘,买一,买一量手,买二,买二量手,买三,买三量手,买四,买四量手,买五,买五量手,卖一,卖一量手,卖二,卖二量手,卖三,卖三量手,卖四,卖四量手,卖五,卖五量手,最近逐笔成交,时间,涨跌,涨幅,最高,最低,价格成交量手成交额,成交量手A,成交额万,换手率,市盈率,nu,最高价,最低价,振幅,流通市值,总市值,市净率,涨停价,跌停价,主力流入,主力流出,主力净流入,主力净流入资金流入流出总和,散户流入,散户流出,散户净流入,散户净流入资金流入流出总和,资金流入流出总和,未知,未知1,日期)'''.format(code)
            cu.execute(st)
            oo = pd.DataFrame(outData.ix[i]).T
            del oo['code']
            oo.to_sql(name=code, con=con ,if_exists='append', index=False)
            print u'写入{0}数据库...'.format(i)
        print u'写入完成...'
        end =  datetime.datetime.now()
        print u'写入耗时:{0}'.format((end - start).seconds)    
    #----------------------------------------------------------------------
    def setData(self):
        """"""
        self.data =  pandasStock.datas()
        return self.data 
    #----------------------------------------------------------------------
    def setDataMoney(self):
        """"""
        self.dataMoney =  pandasStock.moneyDatas()
        return self.dataMoney
    #----------------------------------------------------------------------
    def main(self):
        """"""
        self.setData()
        self.setDataMoney()
        return self.xuanGu()
#----------------------------------------------------------------------
def refrech(sleep=1, limitTime='2017-08-12 20:30:50'):
    """定时写入新数据"""
    n = 0
    while True:
        print time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())  #strftime 将time格式转化为字符串 strptime 将字符串转化为time格式
        #task()
        if time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()) > limitTime:
            print 'time out...'
            break
        elif time.strftime("%a %Y %m %d 11:30:00", time.localtime())  < time.strftime("%a %Y %m %d %H:%M:%S", time.localtime()) <  time.strftime("%a %Y %m %d 13:00:00", time.localtime()):
            time.sleep(60)
        else:
            dt = pandasStock()
            dt.writeNewDateTo_sql()        
            time.sleep(sleep)
            n += 1
            print n
if __name__ == '__main__':
    print path
    refrech()
    #data = getStockData.getStockNewData()
    #dataMoney = getStockData.getStockMoney()
    #columns = data.missage.values()
    #outData = pd.DataFrame(columns = range(49))
    #for x in range(0, len(stockCode), 40):
        #o =  data.getDataMorePandas(stockCode[x:x+40])
        #pdData = pd.DataFrame(o , dtype=None, copy=False)
        #pdDataout = pdData.T        
        #outData = pd.merge(outData, pdDataout, how='outer', indicator=False)
    #outData.columns = columns
    
    #dataDir1 = data.getDataMorePandas(stockCode[:5])
    #columns1 = data.missage.values()
    #pdData1 = pd.DataFrame(dataDir1 , dtype=None, copy=False)
    #pdDataout1 = pdData1.T
    #pdDataout1.columns = columns1
    #pdDataout1.index = pdDataout1[columns1[2]]
    #pdDataout.append(pdDataout1)
    
    #newData = pd.merge(pdDataout, pdDataout1, how='outer')
    #out = pd.ExcelWriter(os.path.dirname(__file__).replace('\\', '/')+'/outTest.xls')    
    #outData.to_excel(out,sheet_name = time.strftime("%Y%m%d %H-%M-%S", time.localtime()))
    #out.save()
    #a = pdDataout1[pdDataout1[columns[7]]>70000] 
    #b = pdDataout1[pdDataout1[columns[38]]>=1.0]
    #print b[b.index.isin(a.index)]
    #print pdDataout1.index.ix[600008]
    #print a.ix[str(600000), [columns[0], columns[1],columns[10]]]
    #print a.ix[str(600000), :5]

    #print pdDataout1.tail(3)
    #print pdDataout1[((pdDataout1[columns[7]] -pdDataout1[columns[8]])/(pdDataout1[columns[7]] +pdDataout1[columns[8]]) )*100 > 10 ]
    #print (pdDataout1.columns[7]-pdData  out1.columns[8])/(pdDataout1.columns[7]+pdDataout1.columns[8])*100 >= 20
    
    
    #dataMoneyDir = dataMoney.getDataMorePandas(shanghaiAgu.stockCode1[:5])
    #dataMoneyDir1 = data.getDataMorePandas(shanghaiAgu.stockCode1[:5])
    #dataM = pd.DataFrame(dataMoneyDir)
    #dataMNew = dataM.T
    #dataMNew.colunms = dataMoney.missage.values()
    #dataM1 = pd.DataFrame(dataMoneyDir1)
    #dataMNew1 = dataM1.T
    #dataMNew1.columns = columns
    #ne = pd.merge(dataMNew1,dataMNew)
    #pdDataout1.to_excel(os.path.dirname(__file__).replace('\\', '/')+'/outTest1.xls',sheet_name = time.strftime("%Y%m%d %H-%M-%S", time.localtime()))
    #print ne.tail(2)
    
    #outData = pandasStock.datas(allStockCode = False, stockCodes= ['sz002232'])
    #print outData.columns#outData[outData.columns[42]]
    #pdata = pandasStock.moneyDatas()
    ##print pdata.columns[4]
    #print pdata[pdata[pdata.columns[4]]> 5.0]
    #print type(pdata[pdata.columns[4]][0]), pdata[pdata.columns[4]][0]