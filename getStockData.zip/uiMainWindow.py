# -*- coding: utf-8 -*-

# MainWindow implementation generated from reading ui file 'C:\Users\zhangshengxin\Desktop\DataWidget.ui'
#
# Created: Thu Jun 04 15:07:06 2015
#      by: PyQt4 UI code generator 4.8.3
#
# WARNING! All changes made in this file will be lost!

#from PySide import QtCore, QtGui
import os
#import maya.OpenMayaUI as omui
#import maya.OpenMaya as  om
try:
    from  PyQt4 import QtCore, QtGui, uic
    import sip 
except:
    from PySide import QtCore, QtGui
    import pysideuic as uic
    import shiboken as sip

##uiFile = os.path.join(os.path.dirname(__file__), 'MoveOnCvPath.ui')
##----------------------------------------------------------------------
#def getMayaWindow():
    #""""""
    #widget =  omui.MQtUtil.mainWindow()
    #try:
        #return sip.wrapinstance(long(widget), QtCore.QObject)
    #except:
        #return sip.wrapInstance(long(widget), QtGui.QWidget)


path =  os.path.dirname(__file__).replace('\\', '/')
#path =  'D:/stocke'

#print path
class ClickableQLabel(QtGui.QLabel):
    def __init__(self, text=None, parent=None, flags=QtCore.Qt.WindowFlags()):
        if text:
            super(ClickableQLabel, self).__init__(text, parent, flags)
        else:
            super(ClickableQLabel, self).__init__(parent, flags)
  
        self._setupUI()
        self.setStatusTip(self.text())
        self.setStyleSheet("color: rgb(255, 0, 0);selection-color: rgb(255, 255, 0);background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0 rgba(0, 0, 0, 0), stop:0.52 rgba(0, 0, 0, 0), stop:0.565 rgba(82, 121, 76, 33), stop:0.65 rgba(159, 235, 148, 64), stop:0.721925 rgba(255, 238, 150, 129), stop:0.77 rgba(255, 128, 128, 204), stop:0.89 rgba(191, 128, 255, 64), stop:1 rgba(0, 0, 0, 0));")
  
    def mouseReleaseEvent(self, event):
        self.emit(QtCore.SIGNAL("clicked()"))
        #print unicode(self.text().toUtf8(), 'Utf8', 'ignore' )
  
    def _setupUI(self):
        self.setCursor(QtCore.Qt.PointingHandCursor)


class Ui_MainWindow(object):
    #----------------------------------------------------------------------
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.setWindowTitle( "MainWindow")
        MainWindow.resize(397, 287)
        font = QtGui.QFont()
        font.setPointSize(9)  
        QtGui.QApplication.setStyle(QtGui.QStyleFactory.create('Cleanlooks'))
        #create Layout
        #先创建一个总Widget
        self.centralwidget = QtGui.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        
        self.gridLayoutMain =  QtGui.QGridLayout(self.centralwidget)
        self.gridLayoutMain.setObjectName('gridLayoutMain')
        
        self.splitter =  QtGui.QSplitter(self.centralwidget)
        self.splitter.setOrientation(QtCore.Qt.Horizontal)
        self.splitter.setObjectName('splitter')
        
        #子布局1
        self.layoutWidget =  QtGui.QWidget(self.splitter) #设置一个布局Widget
        self.layoutWidget.setObjectName('layoutWidget')
        
        self.verticalLayout =  QtGui.QVBoxLayout(self.layoutWidget)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setObjectName('verticalLayout')
        
        self.label_daiMa =  QtGui.QLabel(self.layoutWidget)
        self.label_daiMa.setObjectName('daiMa')
        self.label_daiMa.setText(u'名称:')
        self.label_daiMa.setFont(font)
        self.label_xuanGuDate =  QtGui.QLabel(self.layoutWidget)
        self.label_xuanGuDate.setObjectName('xuanGuDate')
        self.label_xuanGuDate.setText(u'选股时间:')        
        self.label_xuanGuDate.setFont(font)
        self.verticalLayout.addWidget(self.label_daiMa)
        self.verticalLayout.addWidget(self.label_xuanGuDate)
        
        self.listWidget =  QtGui.QListView(self.layoutWidget)
        self.listWidget.setObjectName('listWidget')
        #QtGui.QListWidgetItem(self.listWidget)
        #QtGui.QListWidgetItem(self.listWidget)
        #QtGui.QListWidgetItem(self.listWidget)
        #self.listWidget.item(0).setText('600027')
        #self.listWidget.item(1).setText('000516')
        #self.listWidget.item(2).setText('600908')
        self.listWidget.setStatusTip('listView')
        self.verticalLayout.addWidget(self.listWidget)
        
        self.button =  QtGui.QPushButton(self.layoutWidget)
        self.button.setText(u'选股刷新')
        self.button.setStatusTip(u'选股刷新')
        self.verticalLayout.addWidget(self.button)
        #子布局2
        self.layoutWidget1 =  QtGui.QWidget(self.splitter) #设置一个布局Widget
        self.layoutWidget1.setObjectName('layoutWidget1')
    
        self.verticalLayout1 =  QtGui.QVBoxLayout(self.layoutWidget1)
        self.verticalLayout1.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout1.setObjectName('verticalLayout1')
    
        self.horizontalLayout =  QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
    
        self.label_day =  ClickableQLabel(u'日', self.layoutWidget1)
        self.label_day.setObjectName('daily')
        self.label_day.setText(u'日')
        self.label_day.setAlignment(QtCore.Qt.AlignHCenter)
        #self.label_day.setStyleSheet("color: rgb(255, 0, 0);")
    
        self.label_time =  ClickableQLabel(u'实时', self.layoutWidget1)
        self.label_time.setObjectName('min')
        self.label_time.setText(u'实时')
        self.label_time.setAlignment(QtCore.Qt.AlignHCenter)
        #self.label_time.setStyleSheet("color: rgb(255, 0, 0);")

        self.zhou_time =  ClickableQLabel(u'周线', self.layoutWidget1)
        self.zhou_time.setObjectName('weekly')
        self.zhou_time.setText(u'周线')
        self.zhou_time.setAlignment(QtCore.Qt.AlignHCenter)
        #self.zhou_time.setStyleSheet("color: rgb(255, 0, 0);")

        self.monthly_time =  ClickableQLabel(u'月线', self.layoutWidget1)
        self.monthly_time.setObjectName('monthly')
        self.monthly_time.setText(u'月线')
        self.monthly_time.setAlignment(QtCore.Qt.AlignHCenter)
        #self.monthly_time.setStyleSheet("color: rgb(255, 0, 0);")

        self.horizontalLayout.addWidget(self.label_day)
        self.horizontalLayout.addWidget(self.label_time)
        self.horizontalLayout.addWidget(self.zhou_time)
        self.horizontalLayout.addWidget(self.monthly_time)
        self.verticalLayout1.addLayout(self.horizontalLayout)
    
        self.widget =  QtGui.QWidget(self.layoutWidget1)
        self.widget.setObjectName('widget')
    
        self.formLayout =  QtGui.QFormLayout(self.widget)
        self.formLayout.setContentsMargins(0, 0, 0, 0)
        self.formLayout.setObjectName('formLayout')
    
        self.image = QtGui.QLabel(self.widget)
        self.image.setObjectName('image')
        self.image.setStatusTip(self.image.objectName())
        self.image.setPixmap(QtGui.QPixmap("D:\\pythonStudy\\stockCode\\scripts\\rc\\sh600004_min.png"))
        self.image.setScaledContents(True)
        self.formLayout.setWidget(0, QtGui.QFormLayout.FieldRole, self.image)
        self.verticalLayout1.addWidget(self.widget)
        self.verticalLayout1.setStretch(1, 1)
        #子布局3
        self.layoutWidget2 =  QtGui.QWidget(self.splitter) #设置一个布局Widget
        self.layoutWidget2.setObjectName('layoutWidget2')        
        #
        self.verticalLayout2 = QtGui.QVBoxLayout(self.layoutWidget2)
        self.verticalLayout2.setObjectName("verticalLayout2")
        
        self.gridLayout = QtGui.QGridLayout()
        self.gridLayout.setObjectName("gridLayout")
    
    
        self.open_lab = QtGui.QLabel(self.layoutWidget2)
        self.open_lab.setObjectName("open_lab")
        self.open_lab.setText(u"开盘:")
        
    
        self.close_lab = QtGui.QLabel(self.layoutWidget2)
        self.close_lab.setObjectName("close")
    
    
        self.new_lab = QtGui.QLabel(self.layoutWidget2)
        self.new_lab.setObjectName("new_lab")
    
    
        self.low_lab = QtGui.QLabel(self.layoutWidget2)
        self.low_lab.setObjectName("low_lab")
    
        self.high_lab = QtGui.QLabel(self.layoutWidget2)
        self.high_lab.setObjectName("high_lab")
    
        self.buy_lab = QtGui.QLabel(self.layoutWidget2)
        self.buy_lab.setObjectName("buy_lab")
    
        self.sell_lab = QtGui.QLabel(self.layoutWidget2)
        self.sell_lab.setObjectName("sell_lab")
    
        self.buy1_lab = QtGui.QLabel(self.layoutWidget2)
        self.buy1_lab.setObjectName("buy1_lab")
    
        self.sell1_lab = QtGui.QLabel(self.layoutWidget2)
        self.sell1_lab.setObjectName("sell1_lab")
    
        self.buy2_lab = QtGui.QLabel(self.layoutWidget2)
        self.buy2_lab.setObjectName("buy2_lab")
    
        self.sell2_lab = QtGui.QLabel(self.layoutWidget2)
        self.sell2_lab.setObjectName("sell2_lab")
    
        self.buy3_lab = QtGui.QLabel(self.layoutWidget2)
        self.buy3_lab.setObjectName("buy3_lab")
    
        self.sell3_lab = QtGui.QLabel(self.layoutWidget2)
        self.sell3_lab.setObjectName("sell3_lab")
    
        self.buy4_lab = QtGui.QLabel(self.layoutWidget2)
        self.buy4_lab.setObjectName("buy4_lab")
    
        self.sell4_lab = QtGui.QLabel(self.layoutWidget2)
        self.sell4_lab.setObjectName("sell4_lab")
    
        self.buy5_lab = QtGui.QLabel(self.layoutWidget2)
        self.buy5_lab.setObjectName("buy5_lab")
    
        self.sell5_lab = QtGui.QLabel(self.layoutWidget2)
        self.sell5_lab.setObjectName("sell5_lab")
    
        self.date_lab = QtGui.QLabel(self.layoutWidget2)
        self.date_lab.setObjectName("date_lab")
        
        self.time_lab = QtGui.QLabel(self.layoutWidget2)
        self.time_lab.setObjectName("time_lab")
        
        self.huanShouLv_lab = QtGui.QLabel(self.layoutWidget2)
        self.huanShouLv_lab.setObjectName("huanShou_lab")
    
        self.zhangDie_lab = QtGui.QLabel(self.layoutWidget2)
        self.zhangDie_lab.setObjectName("zhangDie_lab")
    
        self.neiPan_lab = QtGui.QLabel(self.layoutWidget2)
        self.neiPan_lab.setObjectName("neiPan_lab")        
    
        self.waiPan_lab = QtGui.QLabel(self.layoutWidget2)
        self.waiPan_lab.setObjectName("waiPan_lab")                
    
        self.neiwaiPanBi_lab = QtGui.QLabel(self.layoutWidget2)
        self.neiwaiPanBi_lab.setObjectName("neiwaiPanBi_lab")
    
        self.zhuLiMai_lab = QtGui.QLabel(self.layoutWidget2)
        self.zhuLiMai_lab.setObjectName("zhuLiMai")
        
        self.jinE_lab = QtGui.QLabel(self.layoutWidget2)
        self.jinE_lab.setObjectName("jinE")      
        
        self.zuBJY_lab = QtGui.QLabel(self.layoutWidget2)
        self.zuBJY_lab.setObjectName("zuBJY_lab")              
    
    
        self.gridLayout.addWidget(self.open_lab, 1, 1, 1, 1)
        self.gridLayout.addWidget(self.close_lab, 0, 1, 1, 1)
        self.gridLayout.addWidget(self.new_lab, 1, 0, 1, 1)
        self.gridLayout.addWidget(self.zhangDie_lab, 0, 0, 1, 1)
        self.gridLayout.addWidget(self.low_lab, 2, 0, 1, 1)
        self.gridLayout.addWidget(self.high_lab, 2, 1, 1, 1)
        #self.gridLayout.addWidget(self.buy_lab, 3, 0, 1, 1)
        #self.gridLayout.addWidget(self.sell_lab, 3, 1, 1, 1)
        self.gridLayout.addWidget(self.buy1_lab, 3, 0, 1, 1)
        self.gridLayout.addWidget(self.sell1_lab, 3, 1, 1, 1)
        self.gridLayout.addWidget(self.buy2_lab, 4, 0, 1, 1)
        self.gridLayout.addWidget(self.sell2_lab, 4, 1, 1, 1)
        self.gridLayout.addWidget(self.buy3_lab, 5, 0, 1, 1)
        self.gridLayout.addWidget(self.sell3_lab, 5, 1, 1, 1)
        self.gridLayout.addWidget(self.buy4_lab, 6, 0, 1, 1)
        self.gridLayout.addWidget(self.sell4_lab, 6, 1, 1, 1)
        self.gridLayout.addWidget(self.buy5_lab, 7, 0, 1, 1)
        self.gridLayout.addWidget(self.sell5_lab, 7, 1, 1, 1)
        self.gridLayout.addWidget(self.date_lab, 8, 0, 1, 1)
        self.gridLayout.addWidget(self.time_lab, 8, 1, 1, 1)
    
        self.gridLayout.addWidget(self.huanShouLv_lab, 9, 0, 1, 1)
        #self.gridLayout.addWidget(self.zhangDie_lab, 9, 1, 1, 1)        
    
        self.gridLayout.addWidget(self.neiPan_lab, 10, 0, 1, 1)
        self.gridLayout.addWidget(self.waiPan_lab, 10, 1, 1, 1)
    
        self.gridLayout.addWidget(self.neiwaiPanBi_lab, 11, 1, 1, 1)
        self.gridLayout.addWidget(self.zhuLiMai_lab, 11, 0, 1, 1)     
        self.gridLayout.addWidget(self.jinE_lab,12,0,1,1)
        #self.gridLayout.setHorizontalSpacing(0)
        
        self.verticalLayout2.addLayout(self.gridLayout)
        self.verticalLayout2.addWidget(self.zuBJY_lab)
        self.gridLayout.setSpacing(0)
        self.gridLayoutMain.addWidget(self.splitter, 1, 0, 1, 1)

        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtGui.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 397, 23))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtGui.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        QtCore.QMetaObject.connectSlotsByName(MainWindow)
        
        self.close_lab.setText(QtCore.QString(u"昨收:"))
        self.new_lab.setText(QtCore.QString(u"当前:"))
        self.low_lab.setText(QtCore.QString(u"最低:"))
        self.high_lab.setText(QtCore.QString(u"最高:"))
        #self.buy_lab.setText(u"竞买价：")
        #self.sell_lab.setText(u"竞卖价：")
        self.buy1_lab.setText(QtCore.QString(u"买一:"))
        self.sell1_lab.setText(QtCore.QString(u"卖一:"))
        self.buy2_lab.setText(QtCore.QString(u"买二:"))
        self.sell2_lab.setText(QtCore.QString(u"卖二:"))
        self.buy3_lab.setText(QtCore.QString(u"买三:"))
        self.sell3_lab.setText(QtCore.QString(u"卖三:"))
        self.buy4_lab.setText(QtCore.QString(u"买四:"))
        self.sell4_lab.setText(QtCore.QString(u"卖四:"))
        self.buy5_lab.setText(QtCore.QString(u"买五:"))
        self.sell5_lab.setText(QtCore.QString(u"卖五:"))
        self.date_lab.setText(QtCore.QString(u"日期时间:"))
        self.time_lab.setText(u"")
        self.huanShouLv_lab.setText(QtCore.QString(u'换手率:'))
        self.zhangDie_lab.setText(QtCore.QString(u'涨跌%:'))
        self.neiPan_lab.setText(QtCore.QString(u'内盘:'))
        self.waiPan_lab.setText(QtCore.QString(u'外盘:'))
        self.neiwaiPanBi_lab.setText(QtCore.QString(u'内外%:'))
        self.zhuLiMai_lab.setText(QtCore.QString(u'主力:'))
        self.jinE_lab.setText(QtCore.QString(u'金额(亿):'))
        self.zuBJY_lab.setText(QtCore.QString(u'最近逐步交易:'))
    
        
        self.listWidget.setGeometry(QtCore.QRect(1, 19, 73, 216))
        
        MainWindow.setAutoFillBackground(True)
        self.bt = QtGui.QPalette()
        #self.bt.setColor(QtGui.QPalette.WindowText, QtGui.QColor(255, 255, 255))
        self.bt.setColor(QtGui.QPalette.WindowText, QtGui.QColor(255, 255, 255))
        self.bt.setColor(QtGui.QPalette.Background, QtGui.QColor(50, 50, 50))
        #self.bt.setColor(QtGui.QPalette.Button, QtGui.QColor(200, 50, 8))
        

        
        MainWindow.setPalette(self.bt)
        self.lable = [self.open_lab,self.close_lab,
                      self.new_lab,self.low_lab, 
                      self.high_lab,
                      self.buy1_lab,
                      self.sell1_lab,self.buy2_lab,
                      self.sell2_lab,self.buy3_lab,
                      self.sell3_lab,self.buy4_lab,
                      self.sell4_lab,self.buy5_lab,
                      self.sell5_lab,self.time_lab,
                      self.huanShouLv_lab,
                      self.zhangDie_lab, self.neiPan_lab,
                      self.waiPan_lab, 
                      self.zhuLiMai_lab,
                      self.neiwaiPanBi_lab, self.jinE_lab,
                      self.zuBJY_lab
                      ]
        
        #MainWindow.statusBar().showMessage('Ready')
    def mousePressEvent(self,event):
        #QtGui.QPushButton.mousePressEvent()
        if event.button() == QtCore.Qt.LeftButton:
            self.mouse_press = True
            #self.clicked.emit(True)
            self.move_point = event.globalPos() - self.pos()
            print 'mousePressEvent', self.move_point   
def main():
    import sys
    app = QtGui.QApplication(sys.argv)
    wid =  QtGui.QMainWindow() #getMayaWindow())
    wd = Ui_MainWindow()
    wd.setupUi(wid)
    wid.show()
    sys.exit(app.exec_())
if __name__ == '__main__':
    main()
